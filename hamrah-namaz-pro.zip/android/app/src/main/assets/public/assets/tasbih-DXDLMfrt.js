const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/main-HqU77YMX.js","assets/main-DQvuxdwD.css"])))=>i.map(i=>d[i]);
import{T as e,_ as t,d as n,f as r,i,o as a,p as o,t as s,y as c}from"./main-HqU77YMX.js";var l=[{id:`subhan`,name:`سبحان الله`,ar:`سُبْحَانَا اللَّه`},{id:`hamd`,name:`الحمد لله`,ar:`الْحَمْدُ لِلَّه`},{id:`akbar`,name:`الله أكبر`,ar:`اللَّهَ أَكْبَر`},{id:`istighfar`,name:`استغفر الله`,ar:`أَسْتَغْفِرُ اللَّه`},{id:`tawhid`,name:`لا إله إلا الله`,ar:`لَا إِلَهَ إِلَّا اللَّه`},{id:`salawat`,name:`صلوات بر پیامبر ﷺ`,ar:`صَلَّى اللّٰهُ عَلَیْهِ وَسَلَّمَ`}],u=[33,100,1e3,0],d=null;function f(){if(e.get(`settings`,{}).sound)try{d||=new(window.AudioContext||window.webkitAudioContext);let e=d.createOscillator(),t=d.createGain();e.connect(t),t.connect(d.destination),e.frequency.value=880,e.type=`sine`,t.gain.setValueAtTime(.15,d.currentTime),t.gain.exponentialRampToValueAtTime(.001,d.currentTime+.08),e.start(d.currentTime),e.stop(d.currentTime+.08)}catch{}}var p={state:null,render(t){this.root=t,this.state=e.get(`tasbih`,{dhikr:`subhan`,count:0,target:33,rounds:0,history:[]}),this.customDhikrs=e.get(`tasbih_custom`,[]),this.renderView()},allDhikrs(){return[...l,...this.customDhikrs]},renderView(){let e=this.root,t=this.state;this.allDhikrs().find(e=>e.id===t.dhikr)||this.allDhikrs()[0];let a=t.target>0?Math.min(t.count/t.target,1):0,o=2*Math.PI*148;e.innerHTML=`
      <div class="tasbih-wrap">
        <!-- انتخاب ذکر -->
        <div class="tasbih-dhikr-pick">
          <select class="select" id="tasbih-dhikr" aria-label="انتخاب ذکر">
            ${this.allDhikrs().map(e=>`<option value="${e.id}" ${e.id===t.dhikr?`selected`:``}>${e.name}</option>`).join(``)}
          </select>
          <button class="icon-btn" id="tasbih-custom" title="ذکر اختصاصی" aria-label="ذکر اختصاصی">${i.plus}</button>
        </div>

        <!-- دکمه اصلی -->
        <div class="tasbih-circle" id="tasbih-btn" role="button" tabindex="0" aria-label="افزایش شمارش">
          <svg class="progress-arc" viewBox="0 0 300 300">
            <circle class="arc-track" cx="150" cy="150" r="148"/>
            <circle class="arc-meter" cx="150" cy="150" r="148" stroke-dasharray="${o*a} ${o}"/>
          </svg>
          ${t.rounds>0?`<div class="rounds">${i.flame} ${n(t.rounds)} دور</div>`:``}
          <div class="count" id="tasbih-count">${r(t.count)}</div>
          <div class="of-target" id="tasbih-target">${t.target>0?`از ${r(t.target)}`:`بدون هدف`}</div>
          <div class="tap-hint">${i.hand} برای شمارش لمس کن</div>
        </div>

        <!-- هدف -->
        <div class="chip-row" style="margin-bottom:14px" id="target-chips">
          ${u.map(e=>`<button class="chip ${t.target===e?`active`:``}" data-target="${e}">${e===0?`دلخواه`:n(e)}</button>`).join(``)}
        </div>

        <!-- کنترل‌ها -->
        <div class="tasbih-controls">
          <button class="btn btn-soft" id="tasbih-save">${i.check} ثبت و شروع دور جدید</button>
          <button class="btn btn-ghost" id="tasbih-reset">${i.trash} بازنشانی</button>
        </div>
      </div>

      <!-- تاریخچه -->
      <section class="card" style="margin-top:16px">
        <div class="card-head">
          <h2>تاریخچه تسبیحات</h2>
          <button class="btn btn-ghost btn-sm" id="hist-clear">${i.trash} پاک‌کردن</button>
        </div>
        <div class="tasbih-history">
          ${(t.history||[]).length===0?`<div class="empty">هنوز تسبیحی ثبت نشده است</div>`:t.history.slice(0,30).map(e=>`
              <div class="tasbih-hist-row">
                <span class="th-name">${e.name}</span>
                <span class="th-count">${r(e.count)} بار</span>
                <span class="th-date">${n(e.date.slice(5,10).split(`-`).reverse().join(`/`))}</span>
              </div>`).join(``)}
        </div>
      </section>
    `,this.bind()},bind(){let i=this.root,s=i.querySelector(`#tasbih-btn`),l=()=>{let a=this.state;a.count++;let c=e.get(`settings`,{});c.vibration!==!1&&o(8),f(),i.querySelector(`#tasbih-count`).textContent=r(a.count),a.target>0&&a.count===a.target&&(a.rounds++,s.classList.add(`complete`),setTimeout(()=>s.classList.remove(`complete`),500),c.vibration!==!1&&o([30,50,30]),t(`🌟 دور ${n(a.rounds)} کامل شد!`)),e.set(`tasbih`,a),this.updateArc()};s.addEventListener(`click`,l),s.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),l())}),i.querySelector(`#tasbih-dhikr`).addEventListener(`change`,e=>{this.state.dhikr=e.target.value,this.save()}),i.querySelector(`#tasbih-custom`).addEventListener(`click`,()=>this.addCustomDhikr()),i.querySelectorAll(`#target-chips .chip`).forEach(e=>{e.addEventListener(`click`,()=>{let t=+e.dataset.target;t===0?this.promptTarget():(this.state.target=t,this.save(),this.renderView())})}),i.querySelector(`#tasbih-save`).addEventListener(`click`,()=>{let e=this.state;if(e.count===0){t(`هنوز شمارشی نشده است`,`error`);return}let n=this.allDhikrs().find(t=>t.id===e.dhikr);e.history=e.history||[],e.history.unshift({id:c(),name:n?.name||`ذکر`,count:e.count,date:m()}),e.history.length>200&&(e.history=e.history.slice(0,200)),e.count=0,this.save(),t(`✓ ${r(this.state.history[0].count)} بار «${n?.name}» ثبت شد`),this.renderView(),this.checkAchievements()}),i.querySelector(`#tasbih-reset`).addEventListener(`click`,async()=>{await a(`شمارش فعلی (${r(this.state.count)}) بازنشانی شود؟`,{okLabel:`بازنشانی`,danger:!0})&&(this.state.count=0,this.state.rounds=0,this.save(),this.renderView())}),i.querySelector(`#hist-clear`).addEventListener(`click`,async()=>{await a(`همه تاریخچه تسبیحات پاک شود؟`,{okLabel:`پاک شود`,danger:!0})&&(this.state.history=[],this.save(),this.renderView())})},updateArc(){let e=this.state,t=e.target>0?Math.min(e.count/e.target,1):0,n=2*Math.PI*148,r=this.root.querySelector(`.arc-meter`);r&&r.setAttribute(`stroke-dasharray`,`${n*t} ${n}`)},promptTarget(){let e=document.createElement(`input`);e.type=`number`,e.className=`input`,e.min=`1`,e.max=`100000`,e.value=this.state.target||33,e.placeholder=`مثلاً ۵۰۰`,s(async()=>{let{openModal:e}=await import(`./main-HqU77YMX.js`).then(e=>e.m);return{openModal:e}},__vite__mapDeps([0,1])).then(({openModal:n})=>{n({title:`هدف دلخواه`,body:e,actions:[{label:`ذخیره`,cls:`btn-primary`,onClick:()=>{let n=parseInt(e.value,10);return!n||n<1||n>1e5?(t(`عدد معتبر وارد کن (۱ تا ۱۰۰٬۰۰۰)`,`error`),!1):(this.state.target=n,this.save(),this.renderView(),!0)}},{label:`انصراف`,cls:`btn-ghost`}]})})},addCustomDhikr(){let n=document.createElement(`input`);n.type=`text`,n.className=`input`,n.placeholder=`مثلاً: سبحان الله و ب حمد الله`,n.maxLength=100,s(async()=>{let{openModal:e}=await import(`./main-HqU77YMX.js`).then(e=>e.m);return{openModal:e}},__vite__mapDeps([0,1])).then(({openModal:r})=>{r({title:`ذکر اختصاصی`,body:n,actions:[{label:`افزودن`,cls:`btn-primary`,onClick:()=>{let r=n.value.trim();return r?(this.customDhikrs.push({id:`custom_`+c(),name:r,ar:r}),e.set(`tasbih_custom`,this.customDhikrs),this.state.dhikr=this.customDhikrs[this.customDhikrs.length-1].id,this.save(),this.renderView(),!0):(t(`متن ذکر را وارد کن`,`error`),!1)}},{label:`انصراف`,cls:`btn-ghost`}]})})},save(){e.set(`tasbih`,this.state)},checkAchievements(){s(async()=>{let{computeStats:e,checkAchievements:t}=await import(`./achievements-1WcG2P9F.js`);return{computeStats:e,checkAchievements:t}},[]).then(({computeStats:n,checkAchievements:r})=>{s(async()=>{let{dayKey:e,daysAgoKey:t,todayKey:n,keyToDate:r}=await import(`./main-HqU77YMX.js`).then(e=>e.m);return{dayKey:e,daysAgoKey:t,todayKey:n,keyToDate:r}},__vite__mapDeps([0,1])).then(({dayKey:i,daysAgoKey:a,todayKey:o,keyToDate:s})=>{let c=n(e,{dayKey:i,daysAgoKey:a,todayKey:o,keyToDate:s});r(e,c).length&&t(`🏆 نشان جدید گرفتی!`)})})}};function m(){let e=new Date;return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`}export{p as default};