const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/main-HqU77YMX.js","assets/main-DQvuxdwD.css"])))=>i.map(i=>d[i]);
import{C as e,S as t,T as n,_ as r,d as i,g as a,i as o,n as s,o as c,t as l,v as u,x as d,y as f}from"./main-HqU77YMX.js";var p=[{id:`quran`,name:`قرآن`,icon:`quran`},{id:`dhikr`,name:`ذکر`,icon:`beads`},{id:`hadith`,name:`حدیث`,icon:`book`},{id:`memorize`,name:`حفظ`,icon:`sparkle`},{id:`study`,name:`مطالعه`,icon:`grad`},{id:`other`,name:`سایر`,icon:`target`}],m=[{id:`daily`,name:`روزانه`},{id:`weekly`,name:`هفتگی`}],h={render(e){this.root=e,this.goals=n.get(`goals`,[]),this.renderView()},renderView(){let e=this.root,t=u(),n=this.goals.filter(e=>!e.completed),r=this.goals.filter(e=>e.completed);e.innerHTML=`
      <div class="actions" style="margin-bottom:14px">
        <button class="btn btn-primary" id="goal-add">${o.plus} هدف جدید</button>
      </div>

      <div class="settings-section">اهداف فعال (${i(n.length)})</div>
      ${n.length===0?`<div class="card"><div class="empty">${o.target}<p>هنوز هدفی ثبت نکرده‌ای</p><p class="muted" style="font-size:.75rem">مثلا: روزانه ۱۰ دقیقه قرآن بخوانم</p></div></div>`:n.map(e=>this.goalCard(e,t)).join(``)}

      ${r.length?`
        <div class="settings-section">اهداف تکمیل‌شده (${i(r.length)})</div>
        ${r.map(e=>this.goalCard(e,t,!0)).join(``)}
      `:``}
    `,this.bind()},goalCard(e,t,n=!1){let r=p.find(t=>t.id===e.category)||p[5],a=m.find(t=>t.id===e.frequency)||m[0],s=(e.doneDates||[]).includes(t),c=0;if(e.frequency===`daily`){let t=this.daysSince(e.createdAt);c=t>0?Math.min(Math.round((e.doneDates||[]).length/t*100),100):0}else{let t=Math.max(1,Math.ceil(this.daysSince(e.createdAt)/7));c=Math.min(Math.round((e.doneDates||[]).length/t*100),100)}n&&(c=100);let l=this.goalStreak(e);return`
      <div class="goal-card ${n?`completed`:``}" data-id="${e.id}">
        <div class="goal-top">
          <div class="prayer-icon" style="width:38px;height:38px;border-radius:12px;background:var(--pale);color:var(--deep);display:grid;place-items:center;flex:none">${o[r.icon]}</div>
          <div class="g-title">
            ${e.title}
            <span class="g-sub">${r.name} · ${a.name}${e.target?` · هدف: `+i(e.target):``}${e.reminderTime?` · ⏰ `+i(e.reminderTime):``}</span>
          </div>
        </div>
        <div class="goal-progress">
          <div class="bar"><i style="width:${c}%"></i></div>
          <span class="g-pct">${i(c)}٪</span>
        </div>
        ${l>1?`<div class="goal-streak" style="margin-top:8px">${o.flame} زنجیره ${i(l)} روزه</div>`:``}
        <div class="goal-actions">
          ${n?``:`
            <button class="btn ${s?`btn-soft`:`btn-primary`} btn-sm" data-act="toggle">${s?o.check+` امروز انجام شد`:o.check+` ثبت انجام امروز`}</button>
            <button class="btn btn-ghost btn-sm" data-act="edit">${o.edit} ویرایش</button>
            <button class="btn btn-ghost btn-sm" data-act="complete">${o.trophy} تکمیل</button>
            <button class="btn btn-ghost btn-sm" data-act="delete">${o.trash}</button>
          `}
        </div>
      </div>`},daysSince(e){let t=new Date(e),n=new Date-new Date(t.getFullYear(),t.getMonth(),t.getDate());return Math.max(1,Math.floor(n/864e5)+1)},goalStreak(e){let t=new Set(e.doneDates||[]),n=0;for(let e=0;e<3660;e++){let r=new Date;r.setDate(r.getDate()-e);let i=`${r.getFullYear()}-${String(r.getMonth()+1).padStart(2,`0`)}-${String(r.getDate()).padStart(2,`0`)}`;if(t.has(i))n++;else if(e===0)continue;else break}return n},bind(){let e=this.root;e.querySelector(`#goal-add`).addEventListener(`click`,()=>this.editGoal(null)),e.querySelectorAll(`.goal-card`).forEach(e=>{let t=e.dataset.id,n=this.goals.find(e=>e.id===t);e.querySelector(`[data-act="toggle"]`)?.addEventListener(`click`,()=>{let e=u(),t=(n.doneDates||[]).indexOf(e);t>=0?n.doneDates.splice(t,1):n.doneDates.push(e),this.save(),this.renderView(),this.checkAchievements()}),e.querySelector(`[data-act="edit"]`)?.addEventListener(`click`,()=>this.editGoal(n)),e.querySelector(`[data-act="complete"]`)?.addEventListener(`click`,async()=>{await c(`هدف «${n.title}» به‌عنوان تکمیل‌شده علامت بخورد؟`,{okLabel:`تکمیل`})&&(n.completed=!0,n.completedAt=new Date().toISOString(),this.save(),this.renderView(),r(`🎉 هدف تکمیل شد!`),this.checkAchievements())}),e.querySelector(`[data-act="delete"]`)?.addEventListener(`click`,async()=>{await c(`هدف «${n.title}» حذف شود؟`,{okLabel:`حذف`,danger:!0})&&(this.goals=this.goals.filter(e=>e.id!==t),this.save(),this.renderView())})})},editGoal(n){let i=!!n,o=document.createElement(`input`);o.type=`text`,o.className=`input`,o.maxLength=100,o.placeholder=`مثلا: روزانه ۱۰ دقیقه قرآن بخوانم`,o.value=n?.title||``;let c=document.createElement(`select`);c.className=`select`,c.innerHTML=p.map(e=>`<option value="${e.id}" ${n?.category===e.id?`selected`:``}>${e.name}</option>`).join(``);let l=document.createElement(`select`);l.className=`select`,l.innerHTML=m.map(e=>`<option value="${e.id}" ${n?.frequency===e.id?`selected`:``}>${e.name}</option>`).join(``);let u=document.createElement(`input`);u.type=`number`,u.className=`input`,u.min=`0`,u.max=`100000`,u.placeholder=`اختیاری — مثلا ۱۰ (دقیقه) یا ۵ (آیه)`,u.value=n?.target||``;let h=document.createElement(`input`);h.type=`time`,h.className=`input`,h.value=n?.reminderTime||``;let g=document.createElement(`div`);g.className=`field-error`;let _=document.createElement(`div`);_.innerHTML=`
      <div class="field"><label>عنوان هدف *</label></div>
      <div class="field"><label>دسته</label></div>
      <div class="field"><label>زمان‌بندی</label></div>
      <div class="field"><label>مقدار هدف (اختیاری)</label><div class="hint">مثلا ۱۰ دقیقه قرآن، ۳۳ ذکر، ۱ حدیث</div></div>
      <div class="field"><label>یادآوری (اختیاری)</label><div class="hint">ساعت یادآوری — فقط در صورت باز بودن اپ</div></div>
    `;let v=_.querySelectorAll(`.field`);v[0].append(o),v[1].append(c),v[2].append(l),v[3].append(u),v[4].append(h),_.append(g),a({title:i?`ویرایش هدف`:`هدف جدید`,body:_,actions:[{label:`ذخیره`,cls:`btn-primary`,onClick:()=>{let a=o.value.trim();if(!t(a,100))return g.textContent=`عنوان هدف را وارد کن (حداقل ۲ حرف)`,o.classList.add(`invalid`),!1;let p=u.value===``?0:parseInt(u.value,10);if(p!==0&&!d(p,1,1e5))return g.textContent=`مقدار هدف باید عدد مثبت باشد`,u.classList.add(`invalid`),!1;let m=h.value||``;if(m&&!e(m))return g.textContent=`ساعت یادآوری نامعتبر است`,h.classList.add(`invalid`),!1;let _={title:a,category:c.value,frequency:l.value,target:p,reminderTime:m,doneDates:n?.doneDates||[],createdAt:n?.createdAt||new Date().toISOString(),completed:n?.completed||!1};return i?Object.assign(n,_):this.goals.unshift({id:f(),..._}),this.save(),this.renderView(),r(s.t(`saved`)),!0}},{label:`انصراف`,cls:`btn-ghost`}]})},save(){n.set(`goals`,this.goals)},checkAchievements(){l(async()=>{let{computeStats:e,checkAchievements:t}=await import(`./achievements-1WcG2P9F.js`);return{computeStats:e,checkAchievements:t}},[]).then(({computeStats:e,checkAchievements:t})=>{l(async()=>{let{dayKey:e,daysAgoKey:t,todayKey:n,keyToDate:r}=await import(`./main-HqU77YMX.js`).then(e=>e.m);return{dayKey:e,daysAgoKey:t,todayKey:n,keyToDate:r}},__vite__mapDeps([0,1])).then(({dayKey:i,daysAgoKey:a,todayKey:o,keyToDate:s})=>{let c=e(n,{dayKey:i,daysAgoKey:a,todayKey:o,keyToDate:s});t(n,c).length&&r(`🏆 نشان جدید گرفتی!`)})})}};export{h as default};