import{T as e,_ as t,a as n,c as r,d as i,h as a,i as o,n as s,o as c,r as l,s as u,v as d}from"./main-HqU77YMX.js";import{checkAchievements as f,computeStats as p}from"./achievements-1WcG2P9F.js";var m=[{key:`fajr`,name:`نماز صبح`,ar:`صلاة الفجر`,icon:`sunrise`,rakah:`۲ رکعت`},{key:`dhuhr`,name:`نماز ظهر`,ar:`صلاة الظهر`,icon:`sun`,rakah:`۴ رکعت`},{key:`asr`,name:`نماز عصر`,ar:`صلاة العصر`,icon:`sunset`,rakah:`۴ رکعت`},{key:`maghrib`,name:`نماز مغرب`,ar:`صلاة المغرب`,icon:`dusk`,rakah:`۳ رکعت`},{key:`isha`,name:`نماز عشاء`,ar:`صلاة العشاء`,icon:`moon`,rakah:`۴ رکعت`}];function h(t){return e.get(`day:`+t,{})}var g={state:{dateKey:d(),view:`today`},render(e){this.root=e,this.renderView()},renderView(){let e=this.root,t=this.state.dateKey,n=h(t),r=t===d(),c=a(t),l=0,u=0;m.forEach(e=>{n[e.key]?.done&&l++,n[e.key]?.khushu&&u++});let f=Array.isArray(n.qada)?n.qada:[],p=f.filter(e=>e.done).length,g=r?s.t(`today`):s.formatFullDate(c);e.innerHTML=`
      <!-- انتخاب روز -->
      <div class="day-selector" style="margin-bottom:14px">
        <button class="icon-btn" id="day-prev" aria-label="روز قبل">${o.next}</button>
        <div class="day-label" id="day-label">${g}</div>
        <button class="icon-btn" id="day-next" ${r?`disabled`:``} aria-label="روز بعد">${o.back}</button>
        ${r?``:`<button class="btn btn-soft btn-sm" id="day-today">امروز</button>`}
      </div>

      <!-- آمار روز -->
      <div class="stats" style="margin-bottom:14px">
        <div class="stat"><b>${i(l)}</b><span>ادا</span></div>
        <div class="stat"><b>${i(u)}</b><span>با خشوع</span></div>
        <div class="stat gold"><b>${i(p)}</b><span>قضا جبران‌شده</span></div>
      </div>

      <!-- ادا -->
      <section class="card">
        <div class="card-head">
          <h2>${s.t(`fivePrayers`)} — ادا</h2>
        </div>
        <div id="prayer-list">
          ${m.map(e=>{let t=n[e.key]||{};return`
              <div class="prayer-block ${t.done?`done`:``}" data-key="${e.key}">
                <div class="pb-top">
                  <div class="prayer-icon">${o[e.icon]}</div>
                  <div class="prayer-info">
                    <div class="prayer-name">${e.name}</div>
                    <div class="prayer-ar ar">${e.ar} · ${e.rakah}</div>
                  </div>
                  <div class="pb-actions">
                    <input class="check done-box" type="checkbox" ${t.done?`checked`:``} aria-label="${e.name} ادا">
                  </div>
                </div>
                ${t.done?`
                <div class="khushu-inline">
                  <span>${s.t(`khushuQ`)}</span>
                  <label><input type="checkbox" class="khushu-box" ${t.khushu?`checked`:``}> ثبت خشوع</label>
                </div>`:``}
              </div>`}).join(``)}
        </div>
        <div class="tip green">
          ${o.sparkle}
          <span>${s.t(`khushuNote`)}</span>
        </div>
      </section>

      <!-- قضا -->
      <section class="card">
        <div class="card-head">
          <h2>${s.t(`qadaTitle`)}</h2>
        </div>
        <p class="muted" style="margin-bottom:10px;font-size:.78rem">${s.t(`qadaHint`)}</p>
        <div class="qada-list">
          ${m.map((e,t)=>{let n=f[t]||{};return`
              <label class="qada-item ${n.done?`done`:``}" data-qi="${t}">
                <input type="checkbox" class="qada-box" ${n.done?`checked`:``}>
                <span class="qada-name">${e.name} (قضا)</span>
                <span class="muted" style="font-size:.7rem">${n.at?i(n.at.slice(5,10).split(`-`).reverse().join(`/`)):``}</span>
              </label>`}).join(``)}
        </div>
      </section>

      <!-- یادداشت -->
      <section class="card">
        <div class="card-head"><h2>${s.t(`dailyNote`)}</h2></div>
        <textarea class="input" id="prayer-note" rows="2" maxlength="500" placeholder="${s.t(`dailyNotePh`)}">${n.note||``}</textarea>
        <div class="actions">
          <button class="btn btn-primary btn-sm" id="note-save">${o.check} ${s.t(`save`)}</button>
        </div>
      </section>

      <!-- تقویم -->
      <section class="card calendar">
        <div class="cal-head">
          <button class="icon-btn" id="cal-prev" aria-label="ماه قبل">${o.next}</button>
          <h3 id="cal-title"></h3>
          <button class="icon-btn" id="cal-next" aria-label="ماه بعد">${o.back}</button>
        </div>
        <div class="cal-grid" id="cal-grid"></div>
        <div class="cal-legend">
          <span><i class="l-green"></i>نمازهای ثبت‌شده</span>
          <span><i class="l-gold"></i>قضا</span>
        </div>
      </section>

      <!-- تاریخچه -->
      <section class="card">
        <div class="card-head"><h2>تاریخچه ۱۴ روز اخیر</h2></div>
        <div id="history-list"></div>
      </section>

      <div class="actions">
        <a class="btn btn-soft btn-sm" href="/reports">${o.chart} گزارش کامل</a>
        <button class="btn btn-ghost btn-sm" id="clear-day" ${r?``:`hidden`}>${o.trash} ${s.t(`clearToday`)}</button>
      </div>
    `,this.bind(t),this.renderCalendar(),this.renderHistory()},bind(n){let r=this.root;d(),r.querySelector(`#day-prev`).addEventListener(`click`,()=>this.shiftDay(-1)),r.querySelector(`#day-next`).addEventListener(`click`,()=>this.shiftDay(1)),r.querySelector(`#day-today`)?.addEventListener(`click`,()=>{this.state.dateKey=d(),this.renderView()}),r.querySelectorAll(`#prayer-list .prayer-block`).forEach(t=>{let r=t.querySelector(`.done-box`);r.addEventListener(`change`,()=>{e.update(`day:`+n,e=>(e[t.dataset.key]={...e[t.dataset.key]||{},done:r.checked,khushu:r.checked?e[t.dataset.key]?.khushu:!1,at:r.checked?new Date().toISOString():void 0},e)),this.afterChange()});let i=t.querySelector(`.khushu-box`);i&&i.addEventListener(`change`,()=>{e.update(`day:`+n,e=>(e[t.dataset.key]={...e[t.dataset.key]||{},khushu:i.checked},e)),this.afterChange()})}),r.querySelectorAll(`.qada-item`).forEach(t=>{let r=t.querySelector(`.qada-box`);r.addEventListener(`change`,()=>{let i=+t.dataset.qi;e.update(`day:`+n,e=>{Array.isArray(e.qada)||(e.qada=[]);let t=r.checked?u():void 0;return e.qada[i]={done:r.checked,at:t},e}),this.afterChange()})}),r.querySelector(`#note-save`).addEventListener(`click`,()=>{let i=r.querySelector(`#prayer-note`).value.trim().slice(0,500);e.update(`day:`+n,e=>(e.note=i,e)),t(s.t(`saved`))}),r.querySelector(`#clear-day`)?.addEventListener(`click`,async()=>{await c(s.t(`clearTodayMsg`),{danger:!0,okLabel:`پاک شود`})&&(e.remove(`day:`+n),this.renderView())}),r.querySelector(`#cal-prev`).addEventListener(`click`,()=>this.shiftMonth(-1)),r.querySelector(`#cal-next`).addEventListener(`click`,()=>this.shiftMonth(1))},afterChange(){let n=p(e,{dayKey:u,daysAgoKey:r,todayKey:d,keyToDate:a}),i=f(e,n);this.renderView(),i.length&&t(`🏆 نشان جدید گرفتی!`)},shiftDay(e){let t=a(this.state.dateKey);t.setDate(t.getDate()+e);let n=u(t);n>d()||(this.state.dateKey=n,this.renderView())},calMonth:null,renderCalendar(){let e=this.root;if(!this.calMonth){let e=a(this.state.dateKey);this.calMonth=new Date(e.getFullYear(),e.getMonth(),1)}let t=this.calMonth,r=t.getFullYear(),o=t.getMonth(),s=(new Date(r,o,1).getDay()+1)%7,c=new Date(r,o+1,0).getDate(),u=d();e.querySelector(`#cal-title`).textContent=`${n[o]} ${i(r)}`;let f=e.querySelector(`#cal-grid`),p=l.map(e=>`<div class="cal-dow">${e.slice(0,2)}</div>`).join(``);for(let e=0;e<s;e++)p+=`<div></div>`;for(let e=1;e<=c;e++){let t=`${r}-${String(o+1).padStart(2,`0`)}-${String(e).padStart(2,`0`)}`,n=h(t),a=0;m.forEach(e=>{n[e.key]?.done&&a++});let s=Array.isArray(n.qada)&&n.qada.some(e=>e.done),c=[`cal-day`,t>u?`future`:``,t===u?`today`:``,t===this.state.dateKey?`selected`:``].join(` `);p+=`
        <div class="${c}" data-date="${t}">
          ${s?`<span class="qada-dot"></span>`:``}
          ${i(e)}
          <div class="dots">${`<i></i>`.repeat(a)}</div>
        </div>`}f.innerHTML=p,f.querySelectorAll(`.cal-day:not(.future)`).forEach(e=>{e.addEventListener(`click`,()=>{this.state.dateKey=e.dataset.date,this.calMonth=new Date(a(e.dataset.date)),this.renderView()})})},shiftMonth(e){let t=this.calMonth||new Date;this.calMonth=new Date(t.getFullYear(),t.getMonth()+e,1),this.renderCalendar()},renderHistory(){let e=this.root.querySelector(`#history-list`),t=``;for(let e=13;e>=0;e--){let n=r(e),o=h(n),c=0,l=0,u=0;m.forEach(e=>{o[e.key]?.done&&c++,o[e.key]?.khushu&&l++}),Array.isArray(o.qada)&&(u=o.qada.filter(e=>e.done).length);let d=a(n),f=e===0?s.t(`today`):e===1?s.t(`yesterday`):s.formatDate(d,{weekday:`long`});c>0||u>0||o.note,t+=`
        <div class="history-row" style="display:flex;align-items:center;gap:10px;padding:9px 4px;border-bottom:1px solid var(--line);cursor:pointer" data-date="${n}">
          <span style="flex:1;font-size:.82rem">${f}</span>
          ${u?`<span class="badge gold">قضا ${i(u)}</span>`:``}
          <span class="num" style="font-weight:800;color:var(--deep);font-size:.85rem">${i(c)}/۵</span>
        </div>`}e.innerHTML=t,e.querySelectorAll(`.history-row`).forEach(e=>{e.addEventListener(`click`,()=>{this.state.dateKey=e.dataset.date,this.calMonth=new Date(a(e.dataset.date)),this.renderView()})})}};export{g as default};