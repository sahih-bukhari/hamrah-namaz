import{T as e,a as t,c as n,d as r,f as i,h as a,i as o,l as s,n as c,r as l,v as u}from"./main-HqU77YMX.js";var d=[`fajr`,`dhuhr`,`asr`,`maghrib`,`isha`];function f(t){let n=e.get(`day:`+t,{}),r=0,i=0,a=0;return d.forEach(e=>{n[e]?.done&&r++,n[e]?.khushu&&i++}),Array.isArray(n.qada)&&(a=n.qada.filter(e=>e.done).length),{done:r,khushu:i,qada:a,note:n.note||``}}function p(t=null){return(e.get(`tasbih`,{history:[]}).history||[]).filter(e=>!t||e.date>=t).reduce((e,t)=>e+(t.count||0),0)}var m={state:{period:`week`,month:null},render(e){this.root=e;let t=new Date;this.state.month={y:t.getFullYear(),m:t.getMonth()},this.renderView()},renderView(){let e=this.root,t=this.state.period;e.innerHTML=`
      <div class="report-tabs">
        <button class="chip ${t===`day`?`active`:``}" data-p="day">روزانه</button>
        <button class="chip ${t===`week`?`active`:``}" data-p="week">هفتگی</button>
        <button class="chip ${t===`month`?`active`:``}" data-p="month">ماهانه</button>
        <button class="chip ${t===`year`?`active`:``}" data-p="year">سالانه</button>
      </div>
      <div id="report-body"></div>
      <div class="actions no-print" style="margin-top:6px">
        <button class="btn btn-soft btn-sm" id="rpt-csv">${o.download} خروجی CSV</button>
        <button class="btn btn-ghost btn-sm" id="rpt-print">${o.print} چاپ / PDF</button>
      </div>
    `,e.querySelectorAll(`[data-p]`).forEach(e=>{e.addEventListener(`click`,()=>{this.state.period=e.dataset.p,this.renderView()})}),e.querySelector(`#rpt-csv`).addEventListener(`click`,()=>this.exportCSV()),e.querySelector(`#rpt-print`).addEventListener(`click`,()=>window.print());let n=e.querySelector(`#report-body`);t===`day`?this.renderDay(n):t===`week`?this.renderWeek(n):t===`month`?this.renderMonth(n):this.renderYear(n)},renderDay(t){let n=u(),a=f(n),o=p(),s=e.get(`goals`,[]),l=(s||[]).filter(e=>!e.completed),d=(s||[]).filter(e=>(e.doneDates||[]).includes(n)).length;t.innerHTML=`
      <div class="card">
        <div class="card-head"><h2>گزارش امروز</h2><span class="muted">${c.formatFullDate(new Date)}</span></div>
        <div class="report-summary">
          <div class="stat"><b>${r(a.done)}</b><span>نماز ادا</span></div>
          <div class="stat"><b>${r(a.khushu)}</b><span>با خشوع</span></div>
          <div class="stat gold"><b>${r(a.qada)}</b><span>قضا جبران‌شده</span></div>
          <div class="stat"><b>${i(o)}</b><span>کل تسبیحات</span></div>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><h2>برنامه روزانه</h2></div>
        ${l.length===0?`<div class="empty" style="padding:10px">هدف فعالی ثبت نشده است</div>`:l.map(e=>{let t=(e.doneDates||[]).includes(n);return`
                <div class="compare-row">
                  <span class="cr-label">${e.title}</span>
                  <span class="badge ${t?`green`:`gray`}">${t?`انجام شد`:`باقی‌مانده`}</span>
                </div>`}).join(``)}
        ${l.length?`<div class="muted" style="font-size:.75rem;margin-top:8px">${r(d)} از ${r(l.length)} هدف امروز انجام شده</div>`:``}
      </div>
      ${a.note?`<div class="card"><div class="card-head"><h2>یادداشت امروز</h2></div><p style="font-size:.88rem">${a.note}</p></div>`:``}
    `},renderWeek(e){let t=[];for(let e=6;e>=0;e--){let r=n(e),i=f(r);t.push({k:r,s:i,d:a(r)})}let o=t.reduce((e,t)=>e+t.s.done,0),s=t.reduce((e,t)=>e+t.s.khushu,0),c=t.reduce((e,t)=>e+t.s.qada,0),u=p(n(7)),d=t.reduce((e,t)=>t.s.done>e.s.done?t:e,t[0]),m=t.filter(e=>e.s.done===5).length;e.innerHTML=`
      <div class="card">
        <div class="card-head"><h2>نمودار هفت روز اخیر</h2></div>
        <div class="chart">
          ${t.map(e=>`
            <div class="col">
              <div class="bar-v" style="height:${e.s.done/5*100}%">
                ${e.s.done>0?`<span class="v-label">${r(e.s.done)}</span>`:``}
              </div>
              <div class="d-label">${l[e.d.getDay()].slice(0,2)}</div>
            </div>`).join(``)}
        </div>
        <div class="legend muted" style="font-size:.72rem;margin-top:8px">هر میله، تعداد نمازهای ادا ثبت‌شده در آن روز است (حداکثر ۵).</div>
      </div>
      <div class="card">
        <div class="card-head"><h2>خلاصه هفته</h2></div>
        <div class="report-summary">
          <div class="stat"><b>${r(o)}</b><span>نماز ادا</span></div>
          <div class="stat"><b>${r(s)}</b><span>با خشوع</span></div>
          <div class="stat gold"><b>${r(c)}</b><span>قضا</span></div>
          <div class="stat"><b>${i(u)}</b><span>تسبیحات</span></div>
        </div>
        <div class="compare-row" style="margin-top:10px">
          <span class="cr-label">روزهای کامل (۵/۵)</span>
          <span class="cr-val">${r(m)} روز</span>
        </div>
        <div class="compare-row">
          <span class="cr-label">بهترین روز</span>
          <span class="cr-val">${l[d.d.getDay()]} — ${r(d.s.done)} نماز</span>
        </div>
      </div>
    `},renderMonth(e){let{y:n,m:i}=this.state.month,a=new Date(n,i+1,0).getDate(),s=(new Date(n,i,1).getDay()+1)%7,c=0,d=0,p=0,m=0,h=0,g=[];for(let e=1;e<=a;e++){let t=`${n}-${String(i+1).padStart(2,`0`)}-${String(e).padStart(2,`0`)}`,r=f(t);g.push({day:e,k:t,s:r}),c+=r.done,d+=r.khushu,p+=r.qada,r.done===5&&m++,r.done>0&&h++}let _=Math.round(c/(a*5)*100),v=i===0?11:i-1,y=i===0?n-1:n,b=new Date(y,v+1,0).getDate(),x=0;for(let e=1;e<=b;e++){let t=`${y}-${String(v+1).padStart(2,`0`)}-${String(e).padStart(2,`0`)}`;x+=f(t).done}let S=c-x,C=u();e.innerHTML=`
      <div class="card">
        <div class="cal-head">
          <button class="icon-btn" id="m-prev">${o.next}</button>
          <h3>${t[i]} ${r(n)}</h3>
          <button class="icon-btn" id="m-next">${o.back}</button>
        </div>
        <div class="cal-grid">
          ${l.map(e=>`<div class="cal-dow">${e.slice(0,2)}</div>`).join(``)}
          ${`<div></div>`.repeat(s)}
          ${g.map(e=>`
              <div class="${[`cal-day`,e.k>C?`future`:``,e.k===C?`today`:``].join(` `)}" title="${r(e.s.done)} نماز">
                ${e.s.qada?`<span class="qada-dot"></span>`:``}
                ${r(e.day)}
                <div class="dots">${`<i></i>`.repeat(e.s.done)}</div>
              </div>`).join(``)}
        </div>
        <div class="cal-legend">
          <span><i class="l-green"></i>نمازهای ثبت‌شده</span>
          <span><i class="l-gold"></i>قضا</span>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><h2>خلاصه ماه</h2></div>
        <div class="report-summary">
          <div class="stat"><b>${r(c)}</b><span>نماز ادا</span></div>
          <div class="stat"><b>${r(_)}٪</b><span>درصد تکمیل</span></div>
          <div class="stat"><b>${r(m)}</b><span>روزهای کامل</span></div>
          <div class="stat gold"><b>${r(p)}</b><span>قضا</span></div>
        </div>
        <div class="compare-row" style="margin-top:10px">
          <span class="cr-label">مقایسه با ماه قبل (${t[v]})</span>
          <span class="cr-diff ${S>=0?`up`:`down`}">${S>=0?`+`:``}${r(S)}</span>
        </div>
      </div>
    `,e.querySelector(`#m-prev`).addEventListener(`click`,()=>{this.state.month.m===0?(this.state.month.m=11,this.state.month.y--):this.state.month.m--,this.renderMonth(e)}),e.querySelector(`#m-next`).addEventListener(`click`,()=>{this.state.month.m===11?(this.state.month.m=0,this.state.month.y++):this.state.month.m++,this.renderMonth(e)})},renderYear(e){let n=new Date().getFullYear(),a=[];for(let e=0;e<12;e++){let t=new Date(n,e+1,0).getDate(),r=0,i=0,o=0;for(let a=1;a<=t;a++){let t=f(`${n}-${String(e+1).padStart(2,`0`)}-${String(a).padStart(2,`0`)}`);r+=t.done,i+=t.qada,t.done===5&&o++}a.push({m:e,total:r,qada:i,perfect:o})}let o=a.reduce((e,t)=>e+t.total,0),s=a.reduce((e,t)=>e+t.qada,0),c=a.reduce((e,t)=>t.total>e.total?t:e,a[0]),l=p(`${n}-01-01`),u=a.filter(e=>e.total>0),d=u.length?Math.round(u.reduce((e,t)=>e+t.total/(new Date(n,t.m+1,0).getDate()*5),0)/u.length*100):0;e.innerHTML=`
      <div class="card">
        <div class="card-head"><h2>پیشرفت ۱۲ ماه ${r(n)}</h2></div>
        <div class="chart" style="height:170px">
          ${a.map(e=>{let n=Math.max(...a.map(e=>e.total),1);return`
              <div class="col">
                <div class="bar-v ${e.m===c.m&&e.total>0?`gold`:``}" style="height:${e.total/n*100}%">
                  ${e.total>0?`<span class="v-label">${r(e.total)}</span>`:``}
                </div>
                <div class="d-label">${t[e.m].slice(0,3)}</div>
              </div>`}).join(``)}
        </div>
      </div>
      <div class="card">
        <div class="card-head"><h2>خلاصه سال</h2></div>
        <div class="report-summary">
          <div class="stat"><b>${i(o)}</b><span>نماز ادا</span></div>
          <div class="stat gold"><b>${i(s)}</b><span>قضا</span></div>
          <div class="stat"><b>${i(l)}</b><span>تسبیحات</span></div>
          <div class="stat"><b>${r(d)}٪</b><span>میزان استمرار</span></div>
        </div>
        ${c.total>0?`
        <div class="compare-row" style="margin-top:10px">
          <span class="cr-label">بهترین ماه</span>
          <span class="cr-val">${t[c.m]} — ${r(c.total)} نماز</span>
        </div>`:``}
      </div>
    `},exportCSV(){let t=[[`تاریخ`,`نماز صبح`,`نماز ظهر`,`نماز عصر`,`نماز مغرب`,`نماز عشاء`,`ادا (تعداد)`,`خشوع`,`قضا`,`یادداشت`]];for(let r=89;r>=0;r--){let i=n(r),a=e.get(`day:`+i,{}),o=f(i);t.push([i,a.fajr?.done?`بله`:`خیر`,a.dhuhr?.done?`بله`:`خیر`,a.asr?.done?`بله`:`خیر`,a.maghrib?.done?`بله`:`خیر`,a.isha?.done?`بله`:`خیر`,o.done,o.khushu,o.qada,o.note])}let r=e.get(`tasbih`,{history:[]});t.push([]),t.push([`تاریخ`,`ذکر`,`تعداد تسبیح`]),(r.history||[]).slice(0,200).forEach(e=>t.push([e.date,e.name,e.count])),s(`hamrah-namaz-report-${u()}.csv`,t),toast(`فایل CSV دانلود شد`)}};export{m as default};