import{T as e,_ as t,c as n,d as r,h as i,i as a,s as o,v as s}from"./main-HqU77YMX.js";import{ACHIEVEMENTS as c,checkAchievements as l,computeStats as u}from"./achievements-1WcG2P9F.js";var d={render(e){this.root=e,this.renderView()},renderView(){let d=this.root,f=u(e,{dayKey:o,daysAgoKey:n,todayKey:s,keyToDate:i}),p=l(e,f),m=e.get(`achievements`,{}),h=c.filter(e=>m[e.id]).length;if(d.innerHTML=`
      <div class="card" style="text-align:center;padding:20px">
        <div style="font-size:2rem">🏆</div>
        <h2 style="margin:6px 0 2px">نشان‌های من</h2>
        <p class="muted" style="font-size:.8rem">${r(h)} از ${r(c.length)} نشان</p>
        <div class="bar" style="margin-top:12px"><i style="width:${h/c.length*100}%"></i></div>
      </div>

      <div class="tip green" style="margin-bottom:14px">
        ${a.heart}
        <span>نشان‌ها فقط برای تشویق قدم‌های تو هستند. هر کس با سرعت خودش پیش می‌رود و این برنامه هیچ قضاوتی درباره ایمان کسی نمی‌کند.</span>
      </div>

      <div class="ach-grid">
        ${c.map(e=>{let t=!!m[e.id],n=e.progress(f),i=Math.round(n.current/n.target*100);return`
            <div class="ach-card ${t?`unlocked`:`locked`}">
              <div class="a-icon">${a[e.icon]||a.star}</div>
              <div class="a-name">${e.name}</div>
              <div class="a-desc">${e.desc}</div>
              ${t?`<div class="a-date">${r((m[e.id]||``).slice(0,10).split(`-`).reverse().join(`/`))}</div>`:`
                <div class="ach-progress">
                  <div class="bar"><i style="width:${i}%"></i></div>
                  <div class="p-label">${r(n.current)} از ${r(n.target)}</div>
                </div>`}
            </div>`}).join(``)}
      </div>
    `,p.length){let e=p.map(e=>c.find(t=>t.id===e)?.name).filter(Boolean);t(`🏆 نشان جدید: ${e.join(`، `)}`)}}};export{d as default};