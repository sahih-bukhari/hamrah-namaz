const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/main-HqU77YMX.js","assets/main-DQvuxdwD.css"])))=>i.map(i=>d[i]);
import{T as e,_ as t,d as n,i as r,n as i,t as a}from"./main-HqU77YMX.js";import{n as o,t as s}from"./adhkar-DCnUBxjW.js";var c={state:{cat:null,favsOnly:!1},render(t){this.root=t,this.favs=new Set(e.get(`adhkar_favs`,[])),this.renderView()},renderView(){let e=this.root,t=this.state.cat,i=s;this.state.favsOnly?i=s.filter(e=>this.favs.has(e.id)):t&&(i=s.filter(e=>e.cat===t)),e.innerHTML=`
      <!-- دسته‌ها -->
      <div class="adhkar-cat" style="margin-bottom:16px">
        ${o.map(e=>{let i=e.id===`favs`?this.favs.size:s.filter(t=>t.cat===e.id).length;return`
            <button class="chip ${e.id===`favs`&&this.state.favsOnly||!this.state.favsOnly&&t===e.id?`active`:``}" data-cat="${e.id}" style="flex-direction:column;padding:14px 8px;border-radius:14px">
              ${r[e.icon]}
              <span>${e.name}</span>
              <span class="cnt">${n(i)} ذکر</span>
            </button>`}).join(``)}
      </div>

      <!-- لیست -->
      <div id="dua-list">
        ${i.length===0?`<div class="empty">
              ${r.heart}
              <p>در این دسته ذکری یافت نشد</p>
              ${this.state.favsOnly?`<p class="muted" style="font-size:.75rem">ذکری را با دکمه قلب به علاقه‌مندی‌ها اضافه کن</p>`:``}
            </div>`:i.map(e=>this.duaCard(e)).join(``)}
      </div>
    `,this.bind()},duaCard(e){let t=this.favs.has(e.id);return`
      <div class="dua-card ${t?`fav`:``}" data-id="${e.id}">
        <div class="dua-ar ar">${e.ar}</div>
        <div class="dua-tr">${e.tr}</div>
        <div class="dua-meta">
          <span class="badge green">${r.book} ${e.src}</span>
          ${e.count?`<span class="badge gray">${r.clock} ${e.count}</span>`:``}
          <div class="dua-actions">
            <button class="icon-btn fav-btn ${t?`faved`:``}" data-action="fav" aria-label="علاقه‌مندی">${r.heart}</button>
            <button class="icon-btn" data-action="copy" aria-label="کپی">${r.copy}</button>
          </div>
        </div>
      </div>`},bind(){let n=this.root;n.querySelectorAll(`[data-cat]`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.cat;t===`favs`?(this.state.favsOnly=!this.state.favsOnly,this.state.cat=null):(this.state.favsOnly=!1,this.state.cat=this.state.cat===t?null:t),this.renderView()})}),n.querySelectorAll(`.dua-card`).forEach(n=>{let r=n.dataset.id,a=s.find(e=>e.id===r);n.querySelector(`[data-action="copy"]`).addEventListener(`click`,async()=>{try{await navigator.clipboard.writeText(a.ar),t(i.t(`copied`))}catch{t(`کپی ممکن نشد`,`error`)}}),n.querySelector(`[data-action="fav"]`).addEventListener(`click`,()=>{this.favs.has(r)?this.favs.delete(r):this.favs.add(r),e.set(`adhkar_favs`,[...this.favs]),this.renderView(),this.checkAchievements()})})},checkAchievements(){a(async()=>{let{computeStats:e,checkAchievements:t}=await import(`./achievements-1WcG2P9F.js`);return{computeStats:e,checkAchievements:t}},[]).then(({computeStats:n,checkAchievements:r})=>{a(async()=>{let{dayKey:e,daysAgoKey:t,todayKey:n,keyToDate:r}=await import(`./main-HqU77YMX.js`).then(e=>e.m);return{dayKey:e,daysAgoKey:t,todayKey:n,keyToDate:r}},__vite__mapDeps([0,1])).then(({dayKey:i,daysAgoKey:a,todayKey:o,keyToDate:s})=>{let c=n(e,{dayKey:i,daysAgoKey:a,todayKey:o,keyToDate:s});r(e,c).length&&t(`🏆 نشان جدید گرفتی!`)})})}};export{c as default};