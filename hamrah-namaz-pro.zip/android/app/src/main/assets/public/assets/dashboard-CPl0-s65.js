import{T as e,_ as t,c as n,d as r,i,n as a,o,v as s}from"./main-HqU77YMX.js";import{r as c}from"./adhkar-DCnUBxjW.js";var l=[{key:`fajr`,name:`نماز صبح`,ar:`صلاة الفجر`,icon:`sunrise`},{key:`dhuhr`,name:`نماز ظهر`,ar:`صلاة الظهر`,icon:`sun`},{key:`asr`,name:`نماز عصر`,ar:`صلاة العصر`,icon:`sunset`},{key:`maghrib`,name:`نماز مغرب`,ar:`صلاة المغرب`,icon:`dusk`},{key:`isha`,name:`نماز عشاء`,ar:`صلاة العشاء`,icon:`moon`}];function u(t){return e.get(`day:`+t,{})}function d(e){let t=0,n=0,r=0;return l.forEach(r=>{e[r.key]?.done&&t++,e[r.key]?.khushu&&n++}),Array.isArray(e.qada)&&(r=e.qada.filter(e=>e.done).length),{done:t,khushu:n,qada:r}}function f(){let e=0,t=0;d(u(s())).done<5&&(t=1);for(let r=t;r<3660&&d(u(n(r))).done>=5;r++)e++;return e}function p(){let e=c;return e[Math.floor(Date.now()/864e5)%e.length]}var m={render(e){let t=s(),n=u(t),o=d(n),c=f(),m=p(),h=2*Math.PI*43;e.innerHTML=`
      <!-- کارت پیشرفت -->
      <section class="card hero">
        <div class="hero-text">
          <h2>${a.t(`dailyProgress`)}</h2>
          <div class="muted">${a.t(`everyPrayer`)}</div>
          ${c>0?`<div style="margin-top:9px"><span class="streak-chip">${i.flame}<span>زنجیره ${r(c)} روزه</span></span></div>`:``}
        </div>
        <div class="ring">
          <svg viewBox="0 0 100 100">
            <circle class="track" cx="50" cy="50" r="43"/>
            <circle class="meter" id="dash-meter" cx="50" cy="50" r="43" stroke-dasharray="${h*o.done/5} ${h}"/>
          </svg>
          <div class="ring-label">
            <b id="dash-frac">${r(o.done)} از ۵</b>
            <span>نماز ادا</span>
          </div>
        </div>
      </section>

      <div class="stats" style="margin-bottom:14px">
        <div class="stat"><b id="st-done">${r(o.done)}</b><span>${a.t(`done`)}</span></div>
        <div class="stat"><b id="st-khushu">${r(o.khushu)}</b><span>${a.t(`withKhushu`)}</span></div>
        <div class="stat gold"><b id="st-qada">${r(o.qada)}</b><span>قضا جبران‌شده</span></div>
      </div>

      <!-- نمازهای امروز -->
      <section class="card">
        <div class="card-head">
          <h2>${a.t(`fivePrayers`)}</h2>
          <span class="muted">${a.t(`markDone`)}</span>
        </div>
        <div id="dash-prayers">
          ${l.map(e=>`
            <div class="prayer ${n[e.key]?.done?`done`:``}" data-key="${e.key}">
              <div class="prayer-icon">${i[e.icon]}</div>
              <div class="prayer-info">
                <div class="prayer-name">${e.name}</div>
                <div class="prayer-ar ar">${e.ar}</div>
              </div>
              <input class="check done-box" type="checkbox" ${n[e.key]?.done?`checked`:``} aria-label="${e.name}">
            </div>
          `).join(``)}
        </div>

        <div class="tip green" style="margin-top:14px">
          ${i.sparkle}
          <span>${a.t(`khushuNote`)}</span>
        </div>

        <div class="actions" style="margin-top:14px">
          <a class="btn btn-soft btn-sm" href="/prayers">${i.mosque} مدیریت کامل نمازها و قضا</a>
          <button class="btn btn-ghost btn-sm" id="dash-clear">${i.trash} ${a.t(`clearToday`)}</button>
        </div>
      </section>

      <!-- ذکر روزانه -->
      <section class="card">
        <div class="card-head"><h2>ذکر روزانه</h2><a class="muted" href="/dhikr">همه اذکار ←</a></div>
        <div class="dhikr-of-day">
          <div class="ar">${m.ar}</div>
          <div class="tr">${m.tr}</div>
          <div style="margin-top:10px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap">
            <button class="btn btn-soft btn-sm" id="dash-dhikr-copy">${i.copy} کپی</button>
            <a class="btn btn-primary btn-sm" href="/tasbih">${i.beads} تسبیح بگو</a>
          </div>
        </div>
      </section>

      <!-- یادداشت روزانه -->
      <section class="card">
        <div class="card-head"><h2>${a.t(`dailyNote`)}</h2></div>
        <textarea class="input" id="dash-note" rows="2" maxlength="500" placeholder="${a.t(`dailyNotePh`)}">${n.note||``}</textarea>
        <div class="actions">
          <button class="btn btn-primary btn-sm" id="dash-note-save">${i.check} ${a.t(`save`)}</button>
        </div>
      </section>

      <!-- دسترسی سریع -->
      <section class="card">
        <div class="card-head"><h2>دسترسی سریع</h2></div>
        <div class="quick-grid">
          <a class="quick-link" href="/reports">${i.chart}<span>${a.t(`reports`)}</span><span class="arrow">${i.back}</span></a>
          <a class="quick-link" href="/quran">${i.quran}<span>${a.t(`quran`)}</span><span class="arrow">${i.back}</span></a>
          <a class="quick-link" href="/goals">${i.target}<span>${a.t(`goals`)}</span><span class="arrow">${i.back}</span></a>
          <a class="quick-link" href="/learn">${i.grad}<span>${a.t(`learn`)}</span><span class="arrow">${i.back}</span></a>
        </div>
      </section>
    `,this.bind(e,t)},bind(n,i){let s=n.querySelector(`#dash-meter`),c=n.querySelector(`#dash-frac`),l=2*Math.PI*43,f=()=>{let e=d(u(i));s.setAttribute(`stroke-dasharray`,`${l*e.done/5} ${l}`),c.textContent=`${r(e.done)} از ۵`,n.querySelector(`#st-done`).textContent=r(e.done),n.querySelector(`#st-khushu`).textContent=r(e.khushu),n.querySelector(`#st-qada`).textContent=r(e.qada)};n.querySelectorAll(`#dash-prayers .prayer`).forEach(n=>{let r=n.querySelector(`.done-box`);r.addEventListener(`change`,()=>{let o=n.dataset.key;e.update(`day:`+i,e=>(e[o]={...e[o]||{},done:r.checked,khushu:r.checked?e[o]?.khushu:!1},e)),n.classList.toggle(`done`,r.checked),f(),t(r.checked?a.t(`prayerDone`):a.t(`prayerUndone`),`success`,1400)})}),n.querySelector(`#dash-clear`).addEventListener(`click`,async()=>{await o(a.t(`clearTodayMsg`),{danger:!0,okLabel:`پاک شود`})&&(e.remove(`day:`+i),location.reload())}),n.querySelector(`#dash-dhikr-copy`).addEventListener(`click`,async()=>{let e=p();try{await navigator.clipboard.writeText(e.ar),t(a.t(`copied`))}catch{t(`کپی ممکن نشد`,`error`)}});let m=n.querySelector(`#dash-note`);n.querySelector(`#dash-note-save`).addEventListener(`click`,()=>{e.update(`day:`+i,e=>(e.note=m.value.trim().slice(0,500),e)),t(a.t(`saved`))})}};export{m as default};