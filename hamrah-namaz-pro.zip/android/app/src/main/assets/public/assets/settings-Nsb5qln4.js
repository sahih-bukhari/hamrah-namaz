import{A as e,D as t,E as n,O as r,T as i,_ as a,b as o,d as s,g as c,i as l,j as u,k as d,o as f,u as p,w as m}from"./main-HqU77YMX.js";var h={render(e){this.root=e,this.s=m.settings(),this.renderView()},renderView(){let t=this.root,r=this.s,a=n(),o=i.get(`user`,null);t.innerHTML=`
      <!-- ظاهر -->
      <div class="settings-section">ظاهر و زبان</div>
      <div class="card">
        <div class="switch-row">
          <div>
            <div class="sw-title">حالت تاریک</div>
            <div class="sw-sub">کاهش خستگی چشم در شب</div>
          </div>
          <label class="switch">
            <input type="checkbox" id="set-theme" ${r.theme===`dark`?`checked`:``}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="switch-row">
          <div>
            <div class="sw-title">زبان دری</div>
            <div class="sw-sub">تغییر املای برخی واژه‌ها و قالب تاریخ</div>
          </div>
          <label class="switch">
            <input type="checkbox" id="set-lang" ${r.language===`dar`?`checked`:``}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="switch-row" style="align-items:center">
          <div>
            <div class="sw-title">اندازه فونت</div>
            <div class="sw-sub">فونت سراسری اپلیکیشن</div>
          </div>
          <div style="display:flex;gap:6px">
            <button class="icon-btn font-btn" id="font-dec">A-</button>
            <span style="font-size:.8rem;font-weight:700;min-width:34px;text-align:center">${s(r.fontScale)}</span>
            <button class="icon-btn font-btn" id="font-inc">A+</button>
          </div>
        </div>
      </div>

      <!-- تعامل -->
      <div class="settings-section">تعامل</div>
      <div class="card">
        <div class="switch-row">
          <div>
            <div class="sw-title">لرزش هنگام تسبیح</div>
            <div class="sw-sub">در صورت پشتیبانی دستگاه</div>
          </div>
          <label class="switch">
            <input type="checkbox" id="set-vibration" ${r.vibration===!1?``:`checked`}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="switch-row">
          <div>
            <div class="sw-title">صدای تسبیح</div>
            <div class="sw-sub">صدای کوتاه با هر لمس</div>
          </div>
          <label class="switch">
            <input type="checkbox" id="set-sound" ${r.sound?`checked`:``}>
            <span class="slider"></span>
          </label>
        </div>
      </div>

      <!-- پشتیبان‌گیری -->
      <div class="settings-section">پشتیبان‌گیری</div>
      <div class="card">
        <p style="font-size:.82rem;margin-bottom:12px">همه اطلاعات تو در همین دستگاه ذخیره می‌شود. برای انتقال به دستگاه دیگر، پشتیبان بگیر و در دستگاه جدید بازیابی کن.</p>
        <div class="actions">
          <button class="btn btn-soft btn-sm" id="set-export">${l.download} خروجی گرفتن (JSON)</button>
          <button class="btn btn-ghost btn-sm" id="set-import">${l.upload} بازیابی از فایل</button>
        </div>
      </div>

      <!-- حساب کاربری -->
      <div class="settings-section">حساب کاربری</div>
      <div class="card">
        ${e?a?`
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
                <div class="prayer-icon" style="width:42px;height:42px;border-radius:50%;background:var(--green);color:#fff;display:grid;place-items:center">${l.user}</div>
                <div style="flex:1">
                  <div style="font-weight:800;font-size:.9rem">${o?.name||o?.email||`کاربر`}</div>
                  <div class="muted" style="font-size:.75rem">همگام‌سازی ابر فعال است</div>
                </div>
              </div>
              <div class="actions">
                <button class="btn btn-ghost btn-sm" id="set-logout">${l.close} خروج از حساب</button>
              </div>`:`
              <p style="font-size:.82rem;margin-bottom:12px">برای همگام‌سازی بین دستگاه‌ها، حساب بساز یا وارد شو.</p>
              <div class="actions">
                <button class="btn btn-primary btn-sm" id="set-login">${l.user} ورود / ثبت‌نام</button>
              </div>`:`
              <p style="font-size:.82rem;margin-bottom:8px">همگام‌سازی ابر (Supabase) فعلاً فعال نیست.</p>
              <p class="muted" style="font-size:.75rem">برای فعال‌سازی، مراحل اتصال را در مستندات پروژه بخوان. تا آن زمان، همه داده‌ها به‌صورت امن روی همین دستگاه ذخیره می‌شوند.</p>
              ${u.pending()?`<div class="tip" style="margin-top:10px">${l.cloud}<span>${s(u.pending())} تغییر در صف همگام‌سازی است</span></div>`:``}`}
      </div>

      <!-- درباره -->
      <div class="settings-section">درباره</div>
      <div class="card">
        <div class="about-row"><span>نسخه</span><b>۱٫۰</b></div>
        <div class="about-row"><span>ذخیره‌سازی</span><b>محلی (offline-first)</b></div>
        <div class="about-row"><span>منبع قرآن</span><b>api.quran.com</b></div>
      </div>

      <!-- خطر -->
      <div class="danger-zone">
        <h3>حذف همه اطلاعات</h3>
        <p>با این کار همه ثبت‌های نماز، تسبیحات، اهداف، یادداشت‌ها و تنظیمات این دستگاه پاک می‌شود. این عمل قابل بازگشت نیست.</p>
        <button class="btn btn-danger btn-sm" id="set-wipe">${l.trash} حذف همه اطلاعات</button>
      </div>
    `,this.bind()},bind(){let e=this.root;e.querySelector(`#set-theme`).addEventListener(`change`,e=>{m.save({theme:e.target.checked?`dark`:`light`}),this.s=m.settings()}),e.querySelector(`#set-lang`).addEventListener(`change`,e=>{m.save({language:e.target.checked?`dar`:`fa`}),this.s=m.settings(),a(`زبان به‌روزرسانی شد`),setTimeout(()=>this.renderView(),100)}),e.querySelector(`#font-inc`).addEventListener(`click`,()=>{let e=Math.min((this.s.fontScale||1)+.1,1.3);m.save({fontScale:e}),this.s=m.settings(),this.renderView()}),e.querySelector(`#font-dec`).addEventListener(`click`,()=>{let e=Math.max((this.s.fontScale||1)-.1,.8);m.save({fontScale:e}),this.s=m.settings(),this.renderView()}),e.querySelector(`#set-vibration`).addEventListener(`change`,e=>{m.save({vibration:e.target.checked}),this.s=m.settings()}),e.querySelector(`#set-sound`).addEventListener(`change`,e=>{m.save({sound:e.target.checked}),this.s=m.settings()}),e.querySelector(`#set-export`).addEventListener(`click`,()=>{let e=i.exportAll();p(`hamrah-namaz-backup-${new Date().toISOString().slice(0,10)}.json`,JSON.stringify(e,null,2),`application/json`),a(`فایل پشتیبان دانلود شد`)}),e.querySelector(`#set-import`).addEventListener(`click`,()=>{let e=document.createElement(`input`);e.type=`file`,e.accept=`.json,application/json`,e.addEventListener(`change`,async()=>{let t=e.files?.[0];if(t)try{let e=await t.text(),n=JSON.parse(e);if(!await f(`داده‌های فعلی با داده‌های فایل پشتیبان جایگزین شوند؟`,{okLabel:`بازیابی`}))return;let r=i.importAll(n);a(`${s(r)} بخش بازیابی شد`),setTimeout(()=>location.reload(),800)}catch{a(`فایل نامعتبر است`,`error`)}}),e.click()}),e.querySelector(`#set-login`)?.addEventListener(`click`,()=>this.authModal()),e.querySelector(`#set-logout`)?.addEventListener(`click`,async()=>{await f(`از حساب خارج شو؟`,{okLabel:`خروج`})&&(await r(),i.remove(`user`),this.renderView(),a(`از حساب خارج شدی`))}),e.querySelector(`#set-wipe`).addEventListener(`click`,async()=>{await f(`همه اطلاعات (نمازها، تسبیحات، اهداف، یادداشت‌ها، نشان‌ها و تنظیمات) برای همیشه پاک شود؟`,{title:`حذف کامل`,okLabel:`بله، همه پاک شود`,danger:!0})&&(i.clearAll(),location.reload())})},authModal(){let e=document.createElement(`input`);e.type=`email`,e.className=`input`,e.placeholder=`example@mail.com`,e.dir=`ltr`;let n=document.createElement(`input`);n.type=`password`,n.className=`input`,n.placeholder=`••••••••`,n.dir=`ltr`,n.minLength=6;let r=document.createElement(`div`);r.className=`field-error`;let s=document.createElement(`div`);s.innerHTML=`
      <p class="muted" style="font-size:.78rem;margin-bottom:12px">ورود برای همگام‌سازی بین دستگاه‌ها. رمز عبور فقط با Supabase مبادله می‌شود.</p>
      <div class="field"><label>ایمیل</label></div>
      <div class="field"><label>رمز عبور (حداقل ۶ کاراکتر)</label></div>
    `;let l=s.querySelectorAll(`.field`);l[0].append(e),l[1].append(n),s.append(r),c({title:`ورود / ثبت‌نام`,body:s,actions:[{label:`ورود`,cls:`btn-primary`,onClick:async()=>{let s=e.value.trim(),c=n.value;if(!o(s))return r.textContent=`ایمیل معتبر وارد کن`,e.classList.add(`invalid`),!1;if(c.length<6)return r.textContent=`رمز عبور حداقل ۶ کاراکتر باشد`,n.classList.add(`invalid`),!1;r.textContent=`در حال ورود...`;try{let e;try{e=await t(s,c)}catch{e=await d(s,c)}return i.set(`user`,{id:e?.id,email:e?.email,name:e?.user_metadata?.name}),a(`ورود موفق بود`),!0}catch(e){return r.textContent=e.message||`خطا در اتصال`,!1}}},{label:`انصراف`,cls:`btn-ghost`}]})}};export{h as default};