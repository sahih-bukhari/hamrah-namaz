/* ===== همراه نماز من — نقطه ورود ===== */

import '../css/base.css';
import '../css/components.css';
import '../css/layout.css';
import '../css/pages.css';

import Store from './core/store.js';
import Theme from './core/theme.js';
import Router from './core/router.js';
import { App } from './core/app.js';

function boot() {
  Store.init();
  Theme.init();

  // پوسته اپ
  App.renderShell();

  // مسیریابی
  Router.init();

  // ثبت PWA (فقط در محیط امن)
  if ('serviceWorker' in navigator && window.isSecureContext) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch((e) => {
        console.warn('[PWA] ثبت service worker ناموفق:', e.message);
      });
    });
  }

  // خطای سراسری
  window.addEventListener('error', (e) => {
    console.error('[App] خطا:', e.error || e.message);
  });
  window.addEventListener('unhandledrejection', (e) => {
    console.error('[App] خطای Promise:', e.reason);
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}
