# ساخت APK — همراه نماز من

این پروژه با **Capacitor** به یک اپلیکیشن اندرویدی واقعی تبدیل شده است.
پوشه‌ی `android/` یک پروژه اندرویدی کامل و استاندارد است (Gradle + WebView).

## چرا APK مستقیم در این سرور ساخته نمی‌شود؟

این سرور **Alpine Linux (musl, aarch64)** است و ابزارهای بومی اندروید
(`aapt2`، `zipalign`) فقط باینری glibc/x86_64 دارند. بنابراین build اندروید
باید روی دستگاه خودتان (یا CI) انجام شود — اما همه‌چیز از قبل آماده است.

## روش ۱ — یک‌فرمانی (پیشنهادی)

```bash
./build-apk.sh
```

این اسکریپت: بررسی Java → بررسی SDK → `npm install` → build وب →
`cap sync android` → `assembleRelease` را خودکار انجام می‌دهد.

## روش ۲ — دستی (مرحله‌به‌مرحله)

### پیش‌نیازها
| ابزار | نسخه | دریافت |
|---|---|---|
| JDK | **17 یا بالاتر** | https://adoptium.net |
| Android SDK | با `platform-36` و `build-tools;36.0.0` | https://developer.android.com/studio (Android Studio) یا `sdkmanager` |
| Node.js | 18+ | https://nodejs.org |

تنظیم متغیر محیطی:
```bash
export ANDROID_HOME=$HOME/Android/Sdk        # یا آدرس SDK شما
export PATH=$PATH:$ANDROID_HOME/platform-tools
```

اگر SDK Manager را از خط فرمان استفاده می‌کنید:
```bash
sdkmanager "platform-tools" "platforms;android-36" "build-tools;36.0.0"
```

### مراحل build
```bash
npm install          # ۱) وابستگی‌ها
npm run build        # ۲) build نسخه وب → dist/
npx cap sync android # ۳) کپی دارایی‌ها به android/
cd android
./gradlew assembleRelease   # ۴) ساخت APK
```

خروجی:
```
android/app/build/outputs/apk/release/app-release-unsigned.apk
```

### امضای APK (برای نصب روی گوشی)
APK خروجیِ release بدون امضا قابل نصب نیست. یک‌بار یک keystore بسازید
و **حتماً فایل آن را امن نگه دارید** (برای آپدیت‌های بعدی هم لازم است):

```bash
keytool -genkeypair -v -keystore mydeen.keystore -alias mydeen \
  -keyalg RSA -keysize 2048 -validity 10000

apksigner sign --ks mydeen.keystore --out app-release.apk \
  app/build/outputs/apk/release/app-release-unsigned.apk

# بررسی امضا:
apksigner verify app-release.apk
```

`app-release.apk` حالا قابل نصب روی هر گوشی اندروید ۷+ (API 24+) است.

## روش ۳ — با Android Studio (ساده‌ترین برای مبتدیان)
1. پوشه‌ی `android/` را در Android Studio باز کنید (Open).
2. صبر کنید Gradle sync شود.
3. منوی **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. APK در مسیر بالا ساخته می‌شود.

برای تست سریع روی گوشی/شبیه‌ساز: **Run ▶** (یک APK debug امضاشده می‌سازد).

## روش ۴ — CI رایگان (GitHub Actions)
اگر بخواهید بدون نصب هیچ چیزی APK بگیرید، ریپازیتوری را روی GitHub
بگذارید و از اکشن‌های `android-actions/setup-android` +
`gradle-build-action` استفاده کنید — در هر run، APK به‌عنوان artifact
قابل دانلود درمی‌آید.

## تنظیمات اپ (capacitor.config.json)
| فیلد | مقدار |
|---|---|
| appId | `com.mydeen.companion` |
| appName | همراه نماز من |
| webDir | `dist` |
| minSdk | 24 (اندروید ۷) |
| targetSdk | 36 |

## تغییرات بعد از build
هر تغییری در کد وب:
```bash
npm run build && npx cap sync android
# سپس دوباره gradlew assembleRelease
```
