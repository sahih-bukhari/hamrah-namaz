/* ===== صفحه اذکار و دعاها =====
 * - دسته‌بندی‌شده
 * - متن عربی + ترجمه + منبع + تعداد
 * - کپی
 * - علاقه‌مندی
 */

import Store from '../js/core/store.js';
import i18n from '../js/core/i18n.js';
import { ICONS, faNum, toast } from '../js/utils/helpers.js';
import { ADHKAR, ADHKAR_CATEGORIES } from '../js/data/adhkar.js';

export default {
  state: { cat: null, favsOnly: false },

  render(root) {
    this.root = root;
    this.favs = new Set(Store.get('adhkar_favs', []));
    this.renderView();
  },

  renderView() {
    const root = this.root;
    const cat = this.state.cat;

    // لیست اذکار بر اساس دسته
    let list = ADHKAR;
    if (this.state.favsOnly) {
      list = ADHKAR.filter((a) => this.favs.has(a.id));
    } else if (cat) {
      list = ADHKAR.filter((a) => a.cat === cat);
    }

    root.innerHTML = `
      <!-- دسته‌ها -->
      <div class="adhkar-cat" style="margin-bottom:16px">
        ${ADHKAR_CATEGORIES.map((c) => {
          const count = c.id === 'favs'
            ? this.favs.size
            : ADHKAR.filter((a) => a.cat === c.id).length;
          const active = (c.id === 'favs' && this.state.favsOnly) || (!this.state.favsOnly && cat === c.id);
          return `
            <button class="chip ${active ? 'active' : ''}" data-cat="${c.id}" style="flex-direction:column;padding:14px 8px;border-radius:14px">
              ${ICONS[c.icon]}
              <span>${c.name}</span>
              <span class="cnt">${faNum(count)} ذکر</span>
            </button>`;
        }).join('')}
      </div>

      <!-- لیست -->
      <div id="dua-list">
        ${list.length === 0
          ? `<div class="empty">
              ${ICONS.heart}
              <p>در این دسته ذکری یافت نشد</p>
              ${this.state.favsOnly ? '<p class="muted" style="font-size:.75rem">ذکری را با دکمه قلب به علاقه‌مندی‌ها اضافه کن</p>' : ''}
            </div>`
          : list.map((a) => this.duaCard(a)).join('')}
      </div>
    `;

    this.bind();
  },

  duaCard(a) {
    const faved = this.favs.has(a.id);
    return `
      <div class="dua-card ${faved ? 'fav' : ''}" data-id="${a.id}">
        <div class="dua-ar ar">${a.ar}</div>
        <div class="dua-tr">${a.tr}</div>
        <div class="dua-meta">
          <span class="badge green">${ICONS.book} ${a.src}</span>
          ${a.count ? `<span class="badge gray">${ICONS.clock} ${a.count}</span>` : ''}
          <div class="dua-actions">
            <button class="icon-btn fav-btn ${faved ? 'faved' : ''}" data-action="fav" aria-label="علاقه‌مندی">${ICONS.heart}</button>
            <button class="icon-btn" data-action="copy" aria-label="کپی">${ICONS.copy}</button>
          </div>
        </div>
      </div>`;
  },

  bind() {
    const root = this.root;

    // دسته‌ها
    root.querySelectorAll('[data-cat]').forEach((el) => {
      el.addEventListener('click', () => {
        const c = el.dataset.cat;
        if (c === 'favs') {
          this.state.favsOnly = !this.state.favsOnly;
          this.state.cat = null;
        } else {
          this.state.favsOnly = false;
          this.state.cat = this.state.cat === c ? null : c;
        }
        this.renderView();
      });
    });

    // عملیات روی کارت‌ها
    root.querySelectorAll('.dua-card').forEach((el) => {
      const id = el.dataset.id;
      const item = ADHKAR.find((a) => a.id === id);

      el.querySelector('[data-action="copy"]').addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(item.ar);
          toast(i18n.t('copied'));
        } catch (e) {
          toast('کپی ممکن نشد', 'error');
        }
      });

      el.querySelector('[data-action="fav"]').addEventListener('click', () => {
        if (this.favs.has(id)) {
          this.favs.delete(id);
        } else {
          this.favs.add(id);
        }
        Store.set('adhkar_favs', [...this.favs]);
        this.renderView();
        this.checkAchievements();
      });
    });
  },

  checkAchievements() {
    import('../js/data/achievements.js').then(({ computeStats, checkAchievements }) => {
      import('../js/utils/helpers.js').then(({ dayKey, daysAgoKey, todayKey, keyToDate }) => {
        const stats = computeStats(Store, { dayKey, daysAgoKey, todayKey, keyToDate });
        const newly = checkAchievements(Store, stats);
        if (newly.length) toast('🏆 نشان جدید گرفتی!');
      });
    });
  }
};
