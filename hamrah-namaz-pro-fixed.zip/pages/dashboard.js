/* ===== صفحه داشبورد =====
 * - کارت پیشرفت امروز (دایره SVG)
 * - آمار ۳‌گانه + زنجیره استمرار
 * - لیست نمازهای امروز (ادا)
 * - یادداشت روزانه
 * - ذکر روزانه
 * - دسترسی سریع
 */

import Store from '../js/core/store.js';
import i18n from '../js/core/i18n.js';
import { ICONS, faNum, todayKey, daysAgoKey, toast, confirmDialog } from '../js/utils/helpers.js';
import { ADHKAR_DAILY } from '../js/data/adhkar.js';

const PRAYERS = [
  { key: 'fajr', name: 'نماز صبح', ar: 'صلاة الفجر', icon: 'sunrise' },
  { key: 'dhuhr', name: 'نماز ظهر', ar: 'صلاة الظهر', icon: 'sun' },
  { key: 'asr', name: 'نماز عصر', ar: 'صلاة العصر', icon: 'sunset' },
  { key: 'maghrib', name: 'نماز مغرب', ar: 'صلاة المغرب', icon: 'dusk' },
  { key: 'isha', name: 'نماز عشاء', ar: 'صلاة العشاء', icon: 'moon' },
];

function dayData(key) {
  return Store.get('day:' + key, {});
}

function countDay(d) {
  let done = 0, qada = 0;
  PRAYERS.forEach((p) => {
    if (d[p.key]?.done) done++;
  });
  if (Array.isArray(d.qada)) qada = d.qada.filter((q) => q.done).length;
  return { done, qada };
}

/** زنجیره: تعداد روزهای پیاپی (از امروز یا دیروز) که حداقل ۵ نماز ثبت شده */
function streak() {
  let n = 0;
  let offset = 0;
  // اگر امروز هنوز کامل نیست، از دیروز شروع می‌کنیم
  const today = countDay(dayData(todayKey()));
  if (today.done < 5) offset = 1;
  for (let i = offset; i < 3660; i++) {
    const d = countDay(dayData(daysAgoKey(i)));
    if (d.done >= 5) n++;
    else break;
  }
  return n;
}

function dhikrOfTheDay() {
  const list = ADHKAR_DAILY;
  const dayIndex = Math.floor(Date.now() / 86400000) % list.length;
  return list[dayIndex];
}

export default {
  render(root) {
    const tk = todayKey();
    const d = dayData(tk);
    const c = countDay(d);
    const st = streak();
    const dh = dhikrOfTheDay();
    const circ = 2 * Math.PI * 43;

    root.innerHTML = `
      <!-- کارت پیشرفت -->
      <section class="card hero">
        <div class="hero-text">
          <h2>${i18n.t('dailyProgress')}</h2>
          <div class="muted">${i18n.t('everyPrayer')}</div>
          ${st > 0 ? `<div style="margin-top:9px"><span class="streak-chip">${ICONS.flame}<span>زنجیره ${faNum(st)} روزه</span></span></div>` : ''}
        </div>
        <div class="ring">
          <svg viewBox="0 0 100 100">
            <circle class="track" cx="50" cy="50" r="43"/>
            <circle class="meter" id="dash-meter" cx="50" cy="50" r="43" stroke-dasharray="${circ * c.done / 5} ${circ}"/>
          </svg>
          <div class="ring-label">
            <b id="dash-frac">${faNum(c.done)} از ۵</b>
            <span>نماز ادا</span>
          </div>
        </div>
      </section>

      <div class="stats" style="margin-bottom:14px">
        <div class="stat"><b id="st-done">${faNum(c.done)}</b><span>${i18n.t('done')}</span></div>
        <div class="stat"><b id="st-remain">${faNum(5 - c.done)}</b><span>${i18n.t('remaining')}</span></div>
        <div class="stat gold"><b id="st-qada">${faNum(c.qada)}</b><span>قضا جبران‌شده</span></div>
      </div>

      <!-- نمازهای امروز -->
      <section class="card">
        <div class="card-head">
          <h2>${i18n.t('fivePrayers')}</h2>
          <span class="muted">${i18n.t('markDone')}</span>
        </div>
        <div id="dash-prayers">
          ${PRAYERS.map((p) => `
            <div class="prayer ${d[p.key]?.done ? 'done' : ''}" data-key="${p.key}">
              <div class="prayer-icon">${ICONS[p.icon]}</div>
              <div class="prayer-info">
                <div class="prayer-name">${p.name}</div>
                <div class="prayer-ar ar">${p.ar}</div>
              </div>
              <input class="check done-box" type="checkbox" ${d[p.key]?.done ? 'checked' : ''} aria-label="${p.name}">
            </div>
          `).join('')}
        </div>

        <div class="tip green" style="margin-top:14px">
          ${ICONS.sparkle}
          <span>هر نماز، یک قدم ارزشمند به‌سوی آرامش.</span>
        </div>

        <div class="actions" style="margin-top:14px">
          <a class="btn btn-soft btn-sm" href="/prayers">${ICONS.mosque} مدیریت کامل نمازها و قضا</a>
          <button class="btn btn-ghost btn-sm" id="dash-clear">${ICONS.trash} ${i18n.t('clearToday')}</button>
        </div>
      </section>

      <!-- ذکر روزانه -->
      <section class="card">
        <div class="card-head"><h2>ذکر روزانه</h2><a class="muted" href="/dhikr">همه اذکار ←</a></div>
        <div class="dhikr-of-day">
          <div class="ar">${dh.ar}</div>
          <div class="tr">${dh.tr}</div>
          <div style="margin-top:10px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap">
            <button class="btn btn-soft btn-sm" id="dash-dhikr-copy">${ICONS.copy} کپی</button>
            <a class="btn btn-primary btn-sm" href="/tasbih">${ICONS.beads} تسبیح بگو</a>
          </div>
        </div>
      </section>

      <!-- یادداشت روزانه -->
      <section class="card">
        <div class="card-head"><h2>${i18n.t('dailyNote')}</h2></div>
        <textarea class="input" id="dash-note" rows="2" maxlength="500" placeholder="${i18n.t('dailyNotePh')}">${d.note || ''}</textarea>
        <div class="actions">
          <button class="btn btn-primary btn-sm" id="dash-note-save">${ICONS.check} ${i18n.t('save')}</button>
        </div>
      </section>

      <!-- دسترسی سریع -->
      <section class="card">
        <div class="card-head"><h2>دسترسی سریع</h2></div>
        <div class="quick-grid">
          <a class="quick-link" href="/reports">${ICONS.chart}<span>${i18n.t('reports')}</span><span class="arrow">${ICONS.back}</span></a>
          <a class="quick-link" href="/quran">${ICONS.quran}<span>${i18n.t('quran')}</span><span class="arrow">${ICONS.back}</span></a>
          <a class="quick-link" href="/goals">${ICONS.target}<span>${i18n.t('goals')}</span><span class="arrow">${ICONS.back}</span></a>
          <a class="quick-link" href="/learn">${ICONS.grad}<span>${i18n.t('learn')}</span><span class="arrow">${ICONS.back}</span></a>
        </div>
      </section>
    `;

    this.bind(root, tk);
  },

  bind(root, tk) {
    const meter = root.querySelector('#dash-meter');
    const frac = root.querySelector('#dash-frac');
    const circ = 2 * Math.PI * 43;

    const refresh = () => {
      const d = dayData(tk);
      const c = countDay(d);
      meter.setAttribute('stroke-dasharray', `${circ * c.done / 5} ${circ}`);
      frac.textContent = `${faNum(c.done)} از ۵`;
      root.querySelector('#st-done').textContent = faNum(c.done);
      root.querySelector('#st-remain').textContent = faNum(5 - c.done);
      root.querySelector('#st-qada').textContent = faNum(c.qada);
    };

    // تیک نمازها
    root.querySelectorAll('#dash-prayers .prayer').forEach((el) => {
      const box = el.querySelector('.done-box');
      box.addEventListener('change', () => {
        const key = el.dataset.key;
        Store.update('day:' + tk, (d) => {
          d[key] = { ...(d[key] || {}), done: box.checked };
          return d;
        });
        el.classList.toggle('done', box.checked);
        refresh();
        toast(box.checked ? i18n.t('prayerDone') : i18n.t('prayerUndone'), 'success', 1400);
      });
    });

    // پاک‌کردن ثبت‌های امروز
    root.querySelector('#dash-clear').addEventListener('click', async () => {
      const ok = await confirmDialog(i18n.t('clearTodayMsg'), { danger: true, okLabel: 'پاک شود' });
      if (!ok) return;
      Store.remove('day:' + tk);
      location.reload();
    });

    // کپی ذکر
    root.querySelector('#dash-dhikr-copy').addEventListener('click', async () => {
      const dh = dhikrOfTheDay();
      try {
        await navigator.clipboard.writeText(dh.ar);
        toast(i18n.t('copied'));
      } catch (e) {
        toast('کپی ممکن نشد', 'error');
      }
    });

    // یادداشت
    const noteEl = root.querySelector('#dash-note');
    root.querySelector('#dash-note-save').addEventListener('click', () => {
      Store.update('day:' + tk, (d) => {
        d.note = noteEl.value.trim().slice(0, 500);
        return d;
      });
      toast(i18n.t('saved'));
    });
  }
};
