/* ===== صفحه گزارش‌های آماری =====
 * همه آمار از داده‌های واقعی localStorage محاسبه می‌شوند.
 * - روزانه / هفتگی / ماهانه / سالانه
 * - مقایسه با دوره قبل
 * - خروجی CSV و چاپ (PDF)
 */

import Store from '../js/core/store.js';
import i18n from '../js/core/i18n.js';
import { ICONS, faNum, faNumBig, dayKey, keyToDate, todayKey, daysAgoKey, downloadCSV, MONTHS_G, DOW, gregorianToJalali, jalaliToGregorian, jalaaliMonthLength, formatJalali } from '../js/utils/helpers.js';

const PRAYERS = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];

function dayStats(k) {
  const d = Store.get('day:' + k, {});
  let done = 0, qada = 0;
  PRAYERS.forEach((p) => {
    if (d[p]?.done) done++;
  });
  if (Array.isArray(d.qada)) qada = d.qada.filter((q) => q.done).length;
  return { done, qada, note: d.note || '' };
}

function tasbihTotal(sinceKey = null) {
  const t = Store.get('tasbih', { history: [] });
  return (t.history || []).filter((h) => !sinceKey || h.date >= sinceKey).reduce((s, h) => s + (h.count || 0), 0);
}

export default {
  state: { period: 'week', month: null },

  render(root) {
    this.root = root;
    const now = new Date();
    const [jy, jm] = gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
    this.state.month = { jy, jm };
    this.renderView();
  },

  renderView() {
    const root = this.root;
    const p = this.state.period;

    root.innerHTML = `
      <div class="report-tabs">
        <button class="chip ${p === 'day' ? 'active' : ''}" data-p="day">روزانه</button>
        <button class="chip ${p === 'week' ? 'active' : ''}" data-p="week">هفتگی</button>
        <button class="chip ${p === 'month' ? 'active' : ''}" data-p="month">ماهانه</button>
        <button class="chip ${p === 'year' ? 'active' : ''}" data-p="year">سالانه</button>
      </div>
      <div id="report-body"></div>
      <div class="actions no-print" style="margin-top:6px">
        <button class="btn btn-soft btn-sm" id="rpt-csv">${ICONS.download} خروجی CSV</button>
        <button class="btn btn-ghost btn-sm" id="rpt-print">${ICONS.print} چاپ / PDF</button>
      </div>
    `;

    root.querySelectorAll('[data-p]').forEach((el) => {
      el.addEventListener('click', () => {
        this.state.period = el.dataset.p;
        this.renderView();
      });
    });
    root.querySelector('#rpt-csv').addEventListener('click', () => this.exportCSV());
    root.querySelector('#rpt-print').addEventListener('click', () => window.print());

    const body = root.querySelector('#report-body');
    if (p === 'day') this.renderDay(body);
    else if (p === 'week') this.renderWeek(body);
    else if (p === 'month') this.renderMonth(body);
    else this.renderYear(body);
  },

  /* ---------- روزانه ---------- */
  renderDay(body) {
    const tk = todayKey();
    const s = dayStats(tk);
    const t = tasbihTotal();
    const goals = Store.get('goals', []);
    const activeGoals = (goals || []).filter((g) => !g.completed);
    const doneGoalsToday = (goals || []).filter((g) => (g.doneDates || []).includes(tk)).length;

    body.innerHTML = `
      <div class="card">
        <div class="card-head"><h2>گزارش امروز</h2><span class="muted">${formatJalali(todayKey())}</span></div>
        <div class="report-summary">
          <div class="stat"><b>${faNum(s.done)}</b><span>نماز ادا</span></div>
          <div class="stat gold"><b>${faNum(s.qada)}</b><span>قضا جبران‌شده</span></div>
          <div class="stat"><b>${faNumBig(t)}</b><span>کل تسبیحات</span></div>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><h2>برنامه روزانه</h2></div>
        ${activeGoals.length === 0
          ? '<div class="empty" style="padding:10px">هدف فعالی ثبت نشده است</div>'
          : activeGoals.map((g) => {
              const done = (g.doneDates || []).includes(tk);
              return `
                <div class="compare-row">
                  <span class="cr-label">${g.title}</span>
                  <span class="badge ${done ? 'green' : 'gray'}">${done ? 'انجام شد' : 'باقی‌مانده'}</span>
                </div>`;
            }).join('')}
        ${activeGoals.length ? `<div class="muted" style="font-size:.75rem;margin-top:8px">${faNum(doneGoalsToday)} از ${faNum(activeGoals.length)} هدف امروز انجام شده</div>` : ''}
      </div>
      ${s.note ? `<div class="card"><div class="card-head"><h2>یادداشت امروز</h2></div><p style="font-size:.88rem">${s.note}</p></div>` : ''}
    `;
  },

  /* ---------- هفتگی ---------- */
  renderWeek(body) {
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const k = daysAgoKey(i);
      const s = dayStats(k);
      days.push({ k, s, d: keyToDate(k) });
    }
    const total = days.reduce((a, x) => a + x.s.done, 0);
    const totalQada = days.reduce((a, x) => a + x.s.qada, 0);
    const tasbih = tasbihTotal(daysAgoKey(7));
    const best = days.reduce((a, x) => (x.s.done > a.s.done ? x : a), days[0]);
    const perfect = days.filter((x) => x.s.done === 5).length;

    const max = 5;
    body.innerHTML = `
      <div class="card">
        <div class="card-head"><h2>نمودار هفت روز اخیر</h2></div>
        <div class="chart">
          ${days.map((x) => `
            <div class="col">
              <div class="bar-v" style="height:${(x.s.done / max) * 100}%">
                ${x.s.done > 0 ? `<span class="v-label">${faNum(x.s.done)}</span>` : ''}
              </div>
              <div class="d-label">${DOW[x.d.getDay()].slice(0, 2)}</div>
            </div>`).join('')}
        </div>
        <div class="legend muted" style="font-size:.72rem;margin-top:8px">هر میله، تعداد نمازهای ادا ثبت‌شده در آن روز است (حداکثر ۵).</div>
      </div>
      <div class="card">
        <div class="card-head"><h2>خلاصه هفته</h2></div>
        <div class="report-summary">
          <div class="stat"><b>${faNum(total)}</b><span>نماز ادا</span></div>
          <div class="stat gold"><b>${faNum(totalQada)}</b><span>قضا</span></div>
          <div class="stat"><b>${faNumBig(tasbih)}</b><span>تسبیحات</span></div>
        </div>
        <div class="compare-row" style="margin-top:10px">
          <span class="cr-label">روزهای کامل (۵/۵)</span>
          <span class="cr-val">${faNum(perfect)} روز</span>
        </div>
        <div class="compare-row">
          <span class="cr-label">بهترین روز</span>
          <span class="cr-val">${DOW[best.d.getDay()]} — ${faNum(best.s.done)} نماز</span>
        </div>
      </div>
    `;
  },

  /* ---------- ماهانه ---------- */
  renderMonth(body) {
    const { jy, jm } = this.state.month;
    const monthLen = jalaaliMonthLength(jy, jm);
    // اولین روز ماه شمسی → میلادی → روز هفته
    const [gy0, gm0, gd0] = jalaliToGregorian(jy, jm, 1);
    const first = new Date(gy0, gm0 - 1, gd0);
    const startDow = (first.getDay() + 1) % 7; // شنبه = 0

    let total = 0, totalQada = 0, perfectDays = 0, activeDays = 0;
    const perDay = [];
    for (let day = 1; day <= monthLen; day++) {
      const [gy, gm, gd] = jalaliToGregorian(jy, jm, day);
      const k = `${gy}-${String(gm).padStart(2, '0')}-${String(gd).padStart(2, '0')}`;
      const s = dayStats(k);
      perDay.push({ day, k, s });
      total += s.done;
      totalQada += s.qada;
      if (s.done === 5) perfectDays++;
      if (s.done > 0) activeDays++;
    }
    const pct = Math.round((total / (monthLen * 5)) * 100);

    // ماه قبل (شمسی)
    let prevJm = jm - 1, prevJy = jy;
    if (prevJm < 1) { prevJm = 12; prevJy--; }
    const prevLen = jalaaliMonthLength(prevJy, prevJm);
    let prevTotal = 0;
    for (let day = 1; day <= prevLen; day++) {
      const [gy, gm, gd] = jalaliToGregorian(prevJy, prevJm, day);
      const k = `${gy}-${String(gm).padStart(2, '0')}-${String(gd).padStart(2, '0')}`;
      prevTotal += dayStats(k).done;
    }
    const diff = total - prevTotal;

    const tk = todayKey();
    body.innerHTML = `
      <div class="card">
        <div class="cal-head">
          <button class="icon-btn" id="m-prev">${ICONS.next}</button>
          <h3>${MONTHS_FA[jm - 1]} ${faNum(jy)}</h3>
          <button class="icon-btn" id="m-next">${ICONS.back}</button>
        </div>
        <div class="cal-grid">
          ${DOW.map((n) => `<div class="cal-dow">${n.slice(0, 2)}</div>`).join('')}
          ${'<div></div>'.repeat(startDow)}
          ${perDay.map((x) => {
            const isFuture = x.k > tk;
            const cls = ['cal-day', isFuture ? 'future' : '', x.k === tk ? 'today' : ''].join(' ');
            return `
              <div class="${cls}" title="${faNum(x.s.done)} نماز">
                ${x.s.qada ? '<span class="qada-dot"></span>' : ''}
                ${faNum(x.day)}
                <div class="dots">${'<i></i>'.repeat(x.s.done)}</div>
              </div>`;
          }).join('')}
        </div>
        <div class="cal-legend">
          <span><i class="l-green"></i>نمازهای ثبت‌شده</span>
          <span><i class="l-gold"></i>قضا</span>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><h2>خلاصه ماه</h2></div>
        <div class="report-summary">
          <div class="stat"><b>${faNum(total)}</b><span>نماز ادا</span></div>
          <div class="stat"><b>${faNum(pct)}٪</b><span>درصد تکمیل</span></div>
          <div class="stat"><b>${faNum(perfectDays)}</b><span>روزهای کامل</span></div>
          <div class="stat gold"><b>${faNum(totalQada)}</b><span>قضا</span></div>
        </div>
        <div class="compare-row" style="margin-top:10px">
          <span class="cr-label">مقایسه با ماه قبل (${MONTHS_FA[prevJm - 1]})</span>
          <span class="cr-diff ${diff >= 0 ? 'up' : 'down'}">${diff >= 0 ? '+' : ''}${faNum(diff)}</span>
        </div>
      </div>
    `;

    body.querySelector('#m-prev').addEventListener('click', () => {
      let { jy, jm } = this.state.month;
      jm--;
      if (jm < 1) { jm = 12; jy--; }
      this.state.month = { jy, jm };
      this.renderMonth(body);
    });
    body.querySelector('#m-next').addEventListener('click', () => {
      let { jy, jm } = this.state.month;
      jm++;
      if (jm > 12) { jm = 1; jy++; }
      this.state.month = { jy, jm };
      this.renderMonth(body);
    });
  },

  /* ---------- سالانه ---------- */
  renderYear(body) {
    const y = new Date().getFullYear();
    const months = [];
    for (let m = 0; m < 12; m++) {
      const daysInMonth = new Date(y, m + 1, 0).getDate();
      let total = 0, qada = 0, perfect = 0;
      for (let day = 1; day <= daysInMonth; day++) {
        const k = `${y}-${String(m + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const s = dayStats(k);
        total += s.done;
        qada += s.qada;
        if (s.done === 5) perfect++;
      }
      months.push({ m, total, qada, perfect });
    }
    const totalYear = months.reduce((a, x) => a + x.total, 0);
    const totalQada = months.reduce((a, x) => a + x.qada, 0);
    const best = months.reduce((a, x) => (x.total > a.total ? x : a), months[0]);
    const tasbihYear = tasbihTotal(`${y}-01-01`);
    // استمرار: میانگین درصد تکمیل ماه‌های دارای داده
    const withData = months.filter((x) => x.total > 0);
    const consistency = withData.length
      ? Math.round(withData.reduce((a, x) => a + x.total / (new Date(y, x.m + 1, 0).getDate() * 5), 0) / withData.length * 100)
      : 0;

    body.innerHTML = `
      <div class="card">
        <div class="card-head"><h2>پیشرفت ۱۲ ماه ${faNum(y)}</h2></div>
        <div class="chart" style="height:170px">
          ${months.map((x) => {
            const maxM = Math.max(...months.map((mm) => mm.total), 1);
            return `
              <div class="col">
                <div class="bar-v ${x.m === best.m && x.total > 0 ? 'gold' : ''}" style="height:${(x.total / maxM) * 100}%">
                  ${x.total > 0 ? `<span class="v-label">${faNum(x.total)}</span>` : ''}
                </div>
                <div class="d-label">${MONTHS_G[x.m].slice(0, 3)}</div>
              </div>`;
          }).join('')}
        </div>
      </div>
      <div class="card">
        <div class="card-head"><h2>خلاصه سال</h2></div>
        <div class="report-summary">
          <div class="stat"><b>${faNumBig(totalYear)}</b><span>نماز ادا</span></div>
          <div class="stat gold"><b>${faNumBig(totalQada)}</b><span>قضا</span></div>
          <div class="stat"><b>${faNumBig(tasbihYear)}</b><span>تسبیحات</span></div>
          <div class="stat"><b>${faNum(consistency)}٪</b><span>میزان استمرار</span></div>
        </div>
        ${best.total > 0 ? `
        <div class="compare-row" style="margin-top:10px">
          <span class="cr-label">بهترین ماه</span>
          <span class="cr-val">${MONTHS_G[best.m]} — ${faNum(best.total)} نماز</span>
        </div>` : ''}
      </div>
    `;
  },

  /* ---------- خروجی CSV ---------- */
  exportCSV() {
    const rows = [['تاریخ', 'نماز صبح', 'نماز ظهر', 'نماز عصر', 'نماز مغرب', 'نماز عشاء', 'ادا (تعداد)', 'قضا', 'یادداشت']];
    // ۹۰ روز اخیر
    for (let i = 89; i >= 0; i--) {
      const k = daysAgoKey(i);
      const d = Store.get('day:' + k, {});
      const s = dayStats(k);
      rows.push([
        k,
        d.fajr?.done ? 'بله' : 'خیر',
        d.dhuhr?.done ? 'بله' : 'خیر',
        d.asr?.done ? 'بله' : 'خیر',
        d.maghrib?.done ? 'بله' : 'خیر',
        d.isha?.done ? 'بله' : 'خیر',
        s.done,
        s.qada,
        s.note
      ]);
    }
    const t = Store.get('tasbih', { history: [] });
    rows.push([]);
    rows.push(['تاریخ', 'ذکر', 'تعداد تسبیح']);
    (t.history || []).slice(0, 200).forEach((h) => rows.push([h.date, h.name, h.count]));
    downloadCSV(`hamrah-namaz-report-${todayKey()}.csv`, rows);
    toast('فایل CSV دانلود شد');
  }
};
