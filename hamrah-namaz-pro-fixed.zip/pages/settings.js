/* ===== صفحه تنظیمات و حساب کاربری =====
 * - زبان (فارسی/دری)
 * - حالت روشن/تاریک
 * - اندازه فونت
 * - لرزش و صدا
 * - پشتیبان‌گیری و بازیابی
 * - حساب کاربری (Supabase اختیاری)
 * - حذف حساب و اطلاعات
 */

import Store from '../js/core/store.js';
import Theme from '../js/core/theme.js';
import i18n from '../js/core/i18n.js';
import { ICONS, faNum, toast, confirmDialog, downloadFile, openModal, validEmail } from '../js/utils/helpers.js';
import { supabaseEnabled, isSignedIn, signIn, signUp, signOut, supabaseQueue } from '../js/core/supabase.js';

export default {
  render(root) {
    this.root = root;
    this.s = Theme.settings();
    this.renderView();
  },

  renderView() {
    const root = this.root;
    const s = this.s;
    const signedIn = isSignedIn();
    const user = Store.get('user', null);

    root.innerHTML = `
      <!-- ظاهر -->
      <div class="settings-section">ظاهر و زبان</div>
      <div class="card">
        <div class="switch-row">
          <div>
            <div class="sw-title">حالت تاریک</div>
            <div class="sw-sub">کاهش خستگی چشم در شب</div>
          </div>
          <label class="switch">
            <input type="checkbox" id="set-theme" ${s.theme === 'dark' ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="switch-row">
          <div>
            <div class="sw-title">زبان دری</div>
            <div class="sw-sub">تغییر املای برخی واژه‌ها و قالب تاریخ</div>
          </div>
          <label class="switch">
            <input type="checkbox" id="set-lang" ${s.language === 'dar' ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="switch-row" style="align-items:center">
          <div>
            <div class="sw-title">اندازه فونت</div>
            <div class="sw-sub">فونت سراسری اپلیکیشن</div>
          </div>
          <div style="display:flex;gap:6px">
            <button class="icon-btn font-btn" id="font-dec">A-</button>
            <span style="font-size:.8rem;font-weight:700;min-width:34px;text-align:center">${faNum(s.fontScale)}</span>
            <button class="icon-btn font-btn" id="font-inc">A+</button>
          </div>
        </div>
      </div>

      <!-- تعامل -->
      <div class="settings-section">تعامل</div>
      <div class="card">
        <div class="switch-row">
          <div>
            <div class="sw-title">لرزش هنگام تسبیح</div>
            <div class="sw-sub">در صورت پشتیبانی دستگاه</div>
          </div>
          <label class="switch">
            <input type="checkbox" id="set-vibration" ${s.vibration !== false ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <div class="switch-row">
          <div>
            <div class="sw-title">صدای تسبیح</div>
            <div class="sw-sub">صدای کوتاه با هر لمس</div>
          </div>
          <label class="switch">
            <input type="checkbox" id="set-sound" ${s.sound ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
      </div>

      <!-- پشتیبان‌گیری -->
      <div class="settings-section">پشتیبان‌گیری</div>
      <div class="card">
        <p style="font-size:.82rem;margin-bottom:12px">همه اطلاعات تو در همین دستگاه ذخیره می‌شود. برای انتقال به دستگاه دیگر، پشتیبان بگیر و در دستگاه جدید بازیابی کن.</p>
        <div class="actions">
          <button class="btn btn-soft btn-sm" id="set-export">${ICONS.download} خروجی گرفتن (JSON)</button>
          <button class="btn btn-ghost btn-sm" id="set-import">${ICONS.upload} بازیابی از فایل</button>
        </div>
      </div>

      <!-- حساب کاربری -->
      <div class="settings-section">حساب کاربری</div>
      <div class="card">
        ${supabaseEnabled
          ? signedIn
            ? `
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
                <div class="prayer-icon" style="width:42px;height:42px;border-radius:50%;background:var(--green);color:#fff;display:grid;place-items:center">${ICONS.user}</div>
                <div style="flex:1">
                  <div style="font-weight:800;font-size:.9rem">${user?.name || user?.email || 'کاربر'}</div>
                  <div class="muted" style="font-size:.75rem">همگام‌سازی ابر فعال است</div>
                </div>
              </div>
              <div class="actions">
                <button class="btn btn-ghost btn-sm" id="set-logout">${ICONS.close} خروج از حساب</button>
              </div>`
            : `
              <p style="font-size:.82rem;margin-bottom:12px">برای همگام‌سازی بین دستگاه‌ها، حساب بساز یا وارد شو.</p>
              <div class="actions">
                <button class="btn btn-primary btn-sm" id="set-login">${ICONS.user} ورود / ثبت‌نام</button>
              </div>`
          : `
              <p style="font-size:.82rem;margin-bottom:8px">همگام‌سازی ابر (Supabase) فعلاً فعال نیست.</p>
              <p class="muted" style="font-size:.75rem">برای فعال‌سازی، مراحل اتصال را در مستندات پروژه بخوان. تا آن زمان، همه داده‌ها به‌صورت امن روی همین دستگاه ذخیره می‌شوند.</p>
              ${supabaseQueue.pending() ? `<div class="tip" style="margin-top:10px">${ICONS.cloud}<span>${faNum(supabaseQueue.pending())} تغییر در صف همگام‌سازی است</span></div>` : ''}`
        }
      </div>

      <!-- درباره -->
      <div class="settings-section">درباره</div>
      <div class="card">
        <div class="about-row"><span>نسخه</span><b>۱٫۰</b></div>
        <div class="about-row"><span>ذخیره‌سازی</span><b>محلی (offline-first)</b></div>
        <div class="about-row"><span>منبع قرآن</span><b>api.quran.com</b></div>
      </div>

      <!-- خطر -->
      <div class="danger-zone">
        <h3>حذف همه اطلاعات</h3>
        <p>با این کار همه ثبت‌های نماز، تسبیحات، اهداف، یادداشت‌ها و تنظیمات این دستگاه پاک می‌شود. این عمل قابل بازگشت نیست.</p>
        <button class="btn btn-danger btn-sm" id="set-wipe">${ICONS.trash} حذف همه اطلاعات</button>
      </div>
    `;

    this.bind();
  },

  bind() {
    const root = this.root;

    // تم
    root.querySelector('#set-theme').addEventListener('change', (e) => {
      Theme.save({ theme: e.target.checked ? 'dark' : 'light' });
      this.s = Theme.settings();
    });

    // زبان
    root.querySelector('#set-lang').addEventListener('change', (e) => {
      Theme.save({ language: e.target.checked ? 'dar' : 'fa' });
      this.s = Theme.settings();
      toast('زبان به‌روزرسانی شد');
      // رندر مجدد برای اعمال ترجمه‌ها
      setTimeout(() => this.renderView(), 100);
    });

    // فونت
    root.querySelector('#font-inc').addEventListener('click', () => {
      const v = Math.min((this.s.fontScale || 1) + 0.1, 1.3);
      Theme.save({ fontScale: v });
      this.s = Theme.settings();
      this.renderView();
    });
    root.querySelector('#font-dec').addEventListener('click', () => {
      const v = Math.max((this.s.fontScale || 1) - 0.1, 0.8);
      Theme.save({ fontScale: v });
      this.s = Theme.settings();
      this.renderView();
    });

    // لرزش
    root.querySelector('#set-vibration').addEventListener('change', (e) => {
      Theme.save({ vibration: e.target.checked });
      this.s = Theme.settings();
    });

    // صدا
    root.querySelector('#set-sound').addEventListener('change', (e) => {
      Theme.save({ sound: e.target.checked });
      this.s = Theme.settings();
    });

    // خروجی
    root.querySelector('#set-export').addEventListener('click', () => {
      const data = Store.exportAll();
      downloadFile(`hamrah-namaz-backup-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(data, null, 2), 'application/json');
      toast('فایل پشتیبان دانلود شد');
    });

    // بازیابی
    root.querySelector('#set-import').addEventListener('click', () => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.json,application/json';
      input.addEventListener('change', async () => {
        const file = input.files?.[0];
        if (!file) return;
        try {
          const text = await file.text();
          const data = JSON.parse(text);
          const ok = await confirmDialog('داده‌های فعلی با داده‌های فایل پشتیبان جایگزین شوند؟', { okLabel: 'بازیابی' });
          if (!ok) return;
          const count = Store.importAll(data);
          toast(`${faNum(count)} بخش بازیابی شد`);
          setTimeout(() => location.reload(), 800);
        } catch (e) {
          toast('فایل نامعتبر است', 'error');
        }
      });
      input.click();
    });

    // ورود / ثبت‌نام
    root.querySelector('#set-login')?.addEventListener('click', () => this.authModal());

    // خروج
    root.querySelector('#set-logout')?.addEventListener('click', async () => {
      const ok = await confirmDialog('از حساب خارج شو؟', { okLabel: 'خروج' });
      if (!ok) return;
      await signOut();
      Store.remove('user');
      this.renderView();
      toast('از حساب خارج شدی');
    });

    // حذف همه
    root.querySelector('#set-wipe').addEventListener('click', async () => {
      const ok = await confirmDialog(
        'همه اطلاعات (نمازها، تسبیحات، اهداف، یادداشت‌ها، نشان‌ها و تنظیمات) برای همیشه پاک شود؟',
        { title: 'حذف کامل', okLabel: 'بله، همه پاک شود', danger: true }
      );
      if (!ok) return;
      Store.clearAll();
      location.reload();
    });
  },

  authModal() {
    const email = document.createElement('input');
    email.type = 'email';
    email.className = 'input';
    email.placeholder = 'example@mail.com';
    email.dir = 'ltr';

    const pass = document.createElement('input');
    pass.type = 'password';
    pass.className = 'input';
    pass.placeholder = '••••••••';
    pass.dir = 'ltr';
    pass.minLength = 6;

    const err = document.createElement('div');
    err.className = 'field-error';

    const form = document.createElement('div');
    form.innerHTML = `
      <p class="muted" style="font-size:.78rem;margin-bottom:12px">ورود برای همگام‌سازی بین دستگاه‌ها. رمز عبور فقط با Supabase مبادله می‌شود.</p>
      <div class="field"><label>ایمیل</label></div>
      <div class="field"><label>رمز عبور (حداقل ۶ کاراکتر)</label></div>
    `;
    const fields = form.querySelectorAll('.field');
    fields[0].append(email);
    fields[1].append(pass);
    form.append(err);

    openModal({
      title: 'ورود / ثبت‌نام',
      body: form,
      actions: [
        {
          label: 'ورود', cls: 'btn-primary',
          onClick: async () => {
            const em = email.value.trim();
            const pw = pass.value;
            if (!validEmail(em)) {
              err.textContent = 'ایمیل معتبر وارد کن';
              email.classList.add('invalid');
              return false;
            }
            if (pw.length < 6) {
              err.textContent = 'رمز عبور حداقل ۶ کاراکتر باشد';
              pass.classList.add('invalid');
              return false;
            }
            err.textContent = 'در حال ورود...';
            try {
              let user;
              try {
                user = await signIn(em, pw);
              } catch (e) {
                // اگر ورود شکست خورد، تلاش برای ثبت‌نام
                user = await signUp(em, pw);
              }
              Store.set('user', { id: user?.id, email: user?.email, name: user?.user_metadata?.name });
              toast('ورود موفق بود');
              return true;
            } catch (e) {
              err.textContent = e.message || 'خطا در اتصال';
              return false;
            }
          }
        },
        { label: 'انصراف', cls: 'btn-ghost' }
      ]
    });
  }
};
