/* ===== صفحه تسبیح دیجیتال =====
 * - شمارنده بزرگ با دکمه لمس
 * - هدف دلخواه (۳۳/۱۰۰/۱۰۰۰/...)
 * - شمارش خودکار دورها
 * - ذخیره خودکار
 * - تاریخچه تسبیحات
 * - لرزش و صدای اختیاری
 * - ذکر اختصاصی
 */

import Store from '../js/core/store.js';
import i18n from '../js/core/i18n.js';
import { ICONS, faNum, faNumBig, toast, confirmDialog, haptic, uid } from '../js/utils/helpers.js';

const DEFAULT_DHIKRS = [
  { id: 'subhan', name: 'سبحان الله', ar: 'سُبْحَانَا اللَّه' },
  { id: 'hamd', name: 'الحمد لله', ar: 'الْحَمْدُ لِلَّه' },
  { id: 'akbar', name: 'الله أكبر', ar: 'اللَّهَ أَكْبَر' },
  { id: 'istighfar', name: 'استغفر الله', ar: 'أَسْتَغْفِرُ اللَّه' },
  { id: 'tawhid', name: 'لا إله إلا الله', ar: 'لَا إِلَهَ إِلَّا اللَّه' },
  { id: 'salawat', name: 'صلوات بر پیامبر ﷺ', ar: 'صَلَّى اللّٰهُ عَلَیْهِ وَسَلَّمَ' }
];

const TARGETS = [33, 100, 1000, 0]; // 0 = دلخواه

let audioCtx = null;

function playClick() {
  const s = Store.get('settings', {});
  if (!s.sound) return;
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.frequency.value = 880;
    osc.type = 'sine';
    gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.08);
    osc.start(audioCtx.currentTime);
    osc.stop(audioCtx.currentTime + 0.08);
  } catch (e) { /* بی‌خطر */ }
}

export default {
  state: null,

  render(root) {
    this.root = root;
    this.state = Store.get('tasbih', {
      dhikr: 'subhan',
      count: 0,
      target: 33,
      rounds: 0,
      history: []
    });
    this.customDhikrs = Store.get('tasbih_custom', []);
    this.renderView();
  },

  allDhikrs() {
    return [...DEFAULT_DHIKRS, ...this.customDhikrs];
  },

  renderView() {
    const root = this.root;
    const s = this.state;
    const dhikr = this.allDhikrs().find((d) => d.id === s.dhikr) || this.allDhikrs()[0];
    const pct = s.target > 0 ? Math.min(s.count / s.target, 1) : 0;
    const circ = 2 * Math.PI * 148;

    root.innerHTML = `
      <div class="tasbih-wrap">
        <!-- انتخاب ذکر -->
        <div class="tasbih-dhikr-pick">
          <select class="select" id="tasbih-dhikr" aria-label="انتخاب ذکر">
            ${this.allDhikrs().map((d) => `<option value="${d.id}" ${d.id === s.dhikr ? 'selected' : ''}>${d.name}</option>`).join('')}
          </select>
          <button class="icon-btn" id="tasbih-custom" title="ذکر اختصاصی" aria-label="ذکر اختصاصی">${ICONS.plus}</button>
        </div>

        <!-- دکمه اصلی -->
        <div class="tasbih-circle" id="tasbih-btn" role="button" tabindex="0" aria-label="افزایش شمارش">
          <svg class="progress-arc" viewBox="0 0 300 300">
            <circle class="arc-track" cx="150" cy="150" r="148"/>
            <circle class="arc-meter" cx="150" cy="150" r="148" stroke-dasharray="${circ * pct} ${circ}"/>
          </svg>
          ${s.rounds > 0 ? `<div class="rounds">${ICONS.flame} ${faNum(s.rounds)} دور</div>` : ''}
          <div class="count" id="tasbih-count">${faNumBig(s.count)}</div>
          <div class="of-target" id="tasbih-target">${s.target > 0 ? `از ${faNumBig(s.target)}` : 'بدون هدف'}</div>
          <div class="tap-hint">${ICONS.hand} برای شمارش لمس کن</div>
        </div>

        <!-- هدف -->
        <div class="chip-row" style="margin-bottom:14px" id="target-chips">
          ${TARGETS.map((t) => `<button class="chip ${s.target === t ? 'active' : ''}" data-target="${t}">${t === 0 ? 'دلخواه' : faNum(t)}</button>`).join('')}
        </div>

        <!-- کنترل‌ها -->
        <div class="tasbih-controls">
          <button class="btn btn-soft" id="tasbih-save">${ICONS.check} ثبت و شروع دور جدید</button>
          <button class="btn btn-ghost" id="tasbih-reset">${ICONS.trash} بازنشانی</button>
        </div>
      </div>

      <!-- تاریخچه -->
      <section class="card" style="margin-top:16px">
        <div class="card-head">
          <h2>تاریخچه تسبیحات</h2>
          <button class="btn btn-ghost btn-sm" id="hist-clear">${ICONS.trash} پاک‌کردن</button>
        </div>
        <div class="tasbih-history">
          ${(s.history || []).length === 0
            ? `<div class="empty">هنوز تسبیحی ثبت نشده است</div>`
            : s.history.slice(0, 30).map((h) => `
              <div class="tasbih-hist-row">
                <span class="th-name">${h.name}</span>
                <span class="th-count">${faNumBig(h.count)} بار</span>
                <span class="th-date">${faNum(h.date.slice(5, 10).split('-').reverse().join('/'))}</span>
              </div>`).join('')}
        </div>
      </section>
    `;

    this.bind();
  },

  bind() {
    const root = this.root;
    const btn = root.querySelector('#tasbih-btn');

    const tap = () => {
      const s = this.state;
      s.count++;
      const settings = Store.get('settings', {});
      if (settings.vibration !== false) haptic(8);
      playClick();

      root.querySelector('#tasbih-count').textContent = faNumBig(s.count);

      // تکمیل دور
      if (s.target > 0 && s.count === s.target) {
        s.rounds++;
        btn.classList.add('complete');
        setTimeout(() => btn.classList.remove('complete'), 500);
        if (settings.vibration !== false) haptic([30, 50, 30]);
        toast(`🌟 دور ${faNum(s.rounds)} کامل شد!`);
      }

      // ذخیره خودکار (throttle: هر تغییر ذخیره می‌شود — مقادیر کوچک)
      Store.set('tasbih', s);
      this.updateArc();
    };

    btn.addEventListener('click', tap);
    btn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        tap();
      }
    });

    // انتخاب ذکر
    root.querySelector('#tasbih-dhikr').addEventListener('change', (e) => {
      this.state.dhikr = e.target.value;
      this.save();
    });

    // ذکر اختصاصی
    root.querySelector('#tasbih-custom').addEventListener('click', () => this.addCustomDhikr());

    // هدف
    root.querySelectorAll('#target-chips .chip').forEach((ch) => {
      ch.addEventListener('click', () => {
        const t = +ch.dataset.target;
        if (t === 0) {
          this.promptTarget();
        } else {
          this.state.target = t;
          this.save();
          this.renderView();
        }
      });
    });

    // ثبت و دور جدید
    root.querySelector('#tasbih-save').addEventListener('click', () => {
      const s = this.state;
      if (s.count === 0) {
        toast('هنوز شمارشی نشده است', 'error');
        return;
      }
      const dhikr = this.allDhikrs().find((d) => d.id === s.dhikr);
      s.history = s.history || [];
      s.history.unshift({
        id: uid(),
        name: dhikr?.name || 'ذکر',
        count: s.count,
        date: dayKeyLocal()
      });
      if (s.history.length > 200) s.history = s.history.slice(0, 200);
      s.count = 0;
      this.save();
      toast(`✓ ${faNumBig(this.state.history[0].count)} بار «${dhikr?.name}» ثبت شد`);
      this.renderView();
      this.checkAchievements();
    });

    // بازنشانی
    root.querySelector('#tasbih-reset').addEventListener('click', async () => {
      const ok = await confirmDialog(`شمارش فعلی (${faNumBig(this.state.count)}) بازنشانی شود؟`, {
        okLabel: 'بازنشانی', danger: true
      });
      if (!ok) return;
      this.state.count = 0;
      this.state.rounds = 0;
      this.save();
      this.renderView();
    });

    // پاک‌کردن تاریخچه
    root.querySelector('#hist-clear').addEventListener('click', async () => {
      const ok = await confirmDialog('همه تاریخچه تسبیحات پاک شود؟', { okLabel: 'پاک شود', danger: true });
      if (!ok) return;
      this.state.history = [];
      this.save();
      this.renderView();
    });
  },

  updateArc() {
    const s = this.state;
    const pct = s.target > 0 ? Math.min(s.count / s.target, 1) : 0;
    const circ = 2 * Math.PI * 148;
    const arc = this.root.querySelector('.arc-meter');
    if (arc) arc.setAttribute('stroke-dasharray', `${circ * pct} ${circ}`);
  },

  promptTarget() {
    const input = document.createElement('input');
    input.type = 'number';
    input.className = 'input';
    input.min = '1';
    input.max = '100000';
    input.value = this.state.target || 33;
    input.placeholder='مثلاً ۵۰۰';

    import('../js/utils/helpers.js').then(({ openModal }) => {
      openModal({
        title: 'هدف دلخواه',
        body: input,
        actions: [
          {
            label: 'ذخیره', cls: 'btn-primary',
            onClick: () => {
              const v = parseInt(input.value, 10);
              if (!v || v < 1 || v > 100000) {
                toast('عدد معتبر وارد کن (۱ تا ۱۰۰٬۰۰۰)', 'error');
                return false;
              }
              this.state.target = v;
              this.save();
              this.renderView();
              return true;
            }
          },
          { label: 'انصراف', cls: 'btn-ghost' }
        ]
      });
    });
  },

  addCustomDhikr() {
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'input';
    input.placeholder = 'مثلاً: سبحان الله و ب حمد الله';
    input.maxLength = 100;

    import('../js/utils/helpers.js').then(({ openModal }) => {
      openModal({
        title: 'ذکر اختصاصی',
        body: input,
        actions: [
          {
            label: 'افزودن', cls: 'btn-primary',
            onClick: () => {
              const v = input.value.trim();
              if (!v) {
                toast('متن ذکر را وارد کن', 'error');
                return false;
              }
              this.customDhikrs.push({ id: 'custom_' + uid(), name: v, ar: v });
              Store.set('tasbih_custom', this.customDhikrs);
              this.state.dhikr = this.customDhikrs[this.customDhikrs.length - 1].id;
              this.save();
              this.renderView();
              return true;
            }
          },
          { label: 'انصراف', cls: 'btn-ghost' }
        ]
      });
    });
  },

  save() {
    Store.set('tasbih', this.state);
  },

  checkAchievements() {
    import('../js/data/achievements.js').then(({ computeStats, checkAchievements }) => {
      import('../js/utils/helpers.js').then(({ dayKey, daysAgoKey, todayKey, keyToDate }) => {
        const stats = computeStats(Store, { dayKey, daysAgoKey, todayKey, keyToDate });
        const newly = checkAchievements(Store, stats);
        if (newly.length) toast('🏆 نشان جدید گرفتی!');
      });
    });
  }
};

function dayKeyLocal() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
