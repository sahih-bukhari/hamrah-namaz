/* ===== صفحه آموزش دین اسلام =====
 * - دسته‌بندی‌شده
 * - درس‌ها با منابع و ارجاعات
 * - علامت‌گذاری درس خوانده‌شده
 * - نمایش پیشرفت
 */

import Store from '../js/core/store.js';
import i18n from '../js/core/i18n.js';
import { ICONS, faNum, toast } from '../js/utils/helpers.js';
import { LEARN_CATEGORIES } from '../js/data/learn.js';

export default {
  state: { cat: null, lesson: null },

  render(root) {
    this.root = root;
    this.completed = new Set(Store.get('learn', { completed: [] }).completed);
    this.renderView();
  },

  save() {
    Store.set('learn', { completed: [...this.completed] });
  },

  renderView() {
    const root = this.root;

    // نمایش درس
    if (this.state.lesson) {
      this.renderLesson();
      return;
    }

    const totalLessons = LEARN_CATEGORIES.reduce((a, c) => a + c.lessons.length, 0);
    const done = this.completed.size;

    root.innerHTML = `
      <div class="card" style="padding:14px">
        <div style="display:flex;align-items:center;gap:10px">
          <div style="flex:1">
            <div style="display:flex;justify-content:space-between;font-size:.78rem;margin-bottom:5px">
              <span style="font-weight:700">پیشرفت مطالعه</span>
              <span class="muted">${faNum(done)} از ${faNum(totalLessons)} درس</span>
            </div>
            <div class="bar"><i style="width:${(done / totalLessons) * 100}%"></i></div>
          </div>
        </div>
      </div>

      <div id="learn-list">
        ${LEARN_CATEGORIES.map((c) => {
          const cDone = c.lessons.filter((l) => this.completed.has(l.id)).length;
          return `
            <div class="learn-cat" data-cat="${c.id}">
              <div class="lc-icon">${ICONS[c.icon] || ICONS.book}</div>
              <div class="lc-info">
                <div class="lc-title">${c.name}</div>
                <div class="lc-sub">${c.lessons.length} درس</div>
              </div>
              <span class="lc-count">${faNum(cDone)}/${faNum(c.lessons.length)}</span>
            </div>`;
        }).join('')}
      </div>
    `;

    root.querySelectorAll('.learn-cat').forEach((el) => {
      el.addEventListener('click', () => {
        this.state.cat = el.dataset.cat;
        this.renderCatView();
      });
    });
  },

  renderCatView() {
    const root = this.root;
    const c = LEARN_CATEGORIES.find((x) => x.id === this.state.cat);
    if (!c) {
      this.state.cat = null;
      this.renderView();
      return;
    }

    root.innerHTML = `
      <div class="actions" style="margin-bottom:12px">
        <button class="btn btn-ghost btn-sm" id="learn-back">${ICONS.next} بازگشت به دسته‌ها</button>
      </div>
      <div class="card">
        <div class="card-head">
          <h2>${c.name}</h2>
          <span class="muted">${c.lessons.length} درس</span>
        </div>
        ${c.lessons.map((l) => {
          const done = this.completed.has(l.id);
          return `
            <div class="lesson-item ${done ? 'done' : ''}" data-id="${l.id}">
              <div class="li-check">${ICONS.check}</div>
              <div class="li-title">${l.title}</div>
            </div>`;
        }).join('')}
      </div>
    `;

    root.querySelector('#learn-back').addEventListener('click', () => {
      this.state.cat = null;
      this.renderView();
    });

    root.querySelectorAll('.lesson-item').forEach((el) => {
      el.addEventListener('click', () => {
        this.state.lesson = el.dataset.id;
        this.renderLesson();
      });
    });
  },

  renderLesson() {
    const root = this.root;
    let lesson = null, cat = null;
    LEARN_CATEGORIES.forEach((c) => {
      c.lessons.forEach((l) => {
        if (l.id === this.state.lesson) {
          lesson = l;
          cat = c;
        }
      });
    });
    if (!lesson) {
      this.state.lesson = null;
      this.renderView();
      return;
    }

    const done = this.completed.has(lesson.id);

    root.innerHTML = `
      <div class="actions" style="margin-bottom:12px">
        <button class="btn btn-ghost btn-sm" id="lesson-back">${ICONS.next} بازگشت</button>
      </div>
      <div class="card">
        <div class="card-head">
          <h2>${lesson.title}</h2>
          <span class="badge gray">${cat.name}</span>
        </div>
        <div class="lesson-body">${lesson.content}</div>
        <div class="actions" style="margin-top:16px">
          <button class="btn ${done ? 'btn-soft' : 'btn-primary'}" id="lesson-done">
            ${ICONS.check} ${done ? 'خوانده‌شده — برای لغو کلیک کن' : 'علامت‌گذاری به‌عنوان خوانده‌شده'}
          </button>
        </div>
      </div>
    `;

    root.querySelector('#lesson-back').addEventListener('click', () => {
      this.state.lesson = null;
      this.renderCatView();
    });

    root.querySelector('#lesson-done').addEventListener('click', () => {
      if (this.completed.has(lesson.id)) this.completed.delete(lesson.id);
      else this.completed.add(lesson.id);
      this.save();
      this.renderLesson();
      this.checkAchievements();
    });
  },

  checkAchievements() {
    import('../js/data/achievements.js').then(({ computeStats, checkAchievements }) => {
      import('../js/utils/helpers.js').then(({ dayKey, daysAgoKey, todayKey, keyToDate }) => {
        const stats = computeStats(Store, { dayKey, daysAgoKey, todayKey, keyToDate });
        const newly = checkAchievements(Store, stats);
        if (newly.length) toast('🏆 نشان جدید گرفتی!');
      });
    });
  }
};
