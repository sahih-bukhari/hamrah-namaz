/* ===== صفحه نشان‌ها و دستاوردها =====
 * فقط تشویقی — بدون قضاوت یا رقابت ناسالم.
 */

import Store from '../js/core/store.js';
import i18n from '../js/core/i18n.js';
import { ICONS, faNum, faNumBig, dayKey, daysAgoKey, todayKey, keyToDate, toast } from '../js/utils/helpers.js';
import { ACHIEVEMENTS, computeStats, checkAchievements } from '../js/data/achievements.js';

export default {
  render(root) {
    this.root = root;
    this.renderView();
  },

  renderView() {
    const root = this.root;
    const stats = computeStats(Store, { dayKey, daysAgoKey, todayKey, keyToDate });
    const newly = checkAchievements(Store, stats);
    const unlocked = Store.get('achievements', {});

    const unlockedCount = ACHIEVEMENTS.filter((a) => unlocked[a.id]).length;

    root.innerHTML = `
      <div class="card" style="text-align:center;padding:20px">
        <div style="font-size:2rem">🏆</div>
        <h2 style="margin:6px 0 2px">نشان‌های من</h2>
        <p class="muted" style="font-size:.8rem">${faNum(unlockedCount)} از ${faNum(ACHIEVEMENTS.length)} نشان</p>
        <div class="bar" style="margin-top:12px"><i style="width:${(unlockedCount / ACHIEVEMENTS.length) * 100}%"></i></div>
      </div>

      <div class="tip green" style="margin-bottom:14px">
        ${ICONS.heart}
        <span>نشان‌ها فقط برای تشویق قدم‌های تو هستند. هر کس با سرعت خودش پیش می‌رود و این برنامه هیچ قضاوتی درباره ایمان کسی نمی‌کند.</span>
      </div>

      <div class="ach-grid">
        ${ACHIEVEMENTS.map((a) => {
          const isUnlocked = !!unlocked[a.id];
          const prog = a.progress(stats);
          const pct = Math.round((prog.current / prog.target) * 100);
          return `
            <div class="ach-card ${isUnlocked ? 'unlocked' : 'locked'}">
              <div class="a-icon">${ICONS[a.icon] || ICONS.star}</div>
              <div class="a-name">${a.name}</div>
              <div class="a-desc">${a.desc}</div>
              ${isUnlocked
                ? `<div class="a-date">${faNum((unlocked[a.id] || '').slice(0, 10).split('-').reverse().join('/'))}</div>`
                : `
                <div class="ach-progress">
                  <div class="bar"><i style="width:${pct}%"></i></div>
                  <div class="p-label">${faNum(prog.current)} از ${faNum(prog.target)}</div>
                </div>`}
            </div>`;
        }).join('')}
      </div>
    `;

    if (newly.length) {
      const names = newly.map((id) => ACHIEVEMENTS.find((a) => a.id === id)?.name).filter(Boolean);
      toast(`🏆 نشان جدید: ${names.join('، ')}`);
    }
  }
};
