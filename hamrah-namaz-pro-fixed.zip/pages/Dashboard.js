/*
 * Dashboard — صفحه پیشرفت امروز
 * - کارت پیشرفت (دایره SVG)
 - آمار ۳‌گانه (ادا، قضا، خشوع)
 - لیست نمازهای امروز با تیک زدن
 - یادداشت روزانه
 - ذکر روزانه پیشنهادی
 */

import { i18n } from '../js/core/i18n.js';
import { Store } from '../js/core/Store.js';

const prayerKeys = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];

function fa(n) {
  return i18n.toPersianDigits(String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]));
}

function keyDate(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function readDay(key) {
  try {
    return JSON.parse(localStorage.getItem('hamrah-pro-' + key) || '{}');
  } catch (e) {
    return {};
  }
}

function writeDay(key, obj) {
  localStorage.setItem('hamrah-pro-' + key, JSON.stringify(obj));
}

export default {
  render() {
    const todayKey = keyDate(new Date());
    let state = readDay(todayKey);

    // Counts
    let done = 0, kh = 0;
    prayerKeys.forEach(k => {
      if (state[k]?.done) done++;
      if (state[k]?.khushu) kh++;
    });

    // Circle circumference for progress
    const circ = 2 * Math.PI * 43;

    // Render today date
    const todayEl = document.createElement('div');
    todayEl.className = 'today';
    todayEl.innerHTML = i18n.formatDate(new Date(), {
      weekday: 'long',
      day: 'numeric',
      month: 'long'
    });

    // Render fraction
    const fractionEl = document.createElement('strong');
    fractionEl.id = 'fraction';
    fractionEl.textContent = `${fa(done)} از ۵`;

    // Render meter
    const meterEl = document.createElement('circle');
    meterEl.className = 'meter';
    meterEl.setAttribute('cx', '50');
    meterEl.setAttribute('cy', '50');
    meterEl.setAttribute('r', '43');
    meterEl.setAttribute('stroke-dasharray', `${circ * done / 5} ${circ}`);
    meterEl.setAttribute('stroke', 'var(--green)');

    // Ring SVG
    const ringSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    ringSvg.setAttribute('viewBox', '0 0 100 100');
    ringSvg.innerHTML = `
      <circle class="track" cx="50" cy="50" r="43" fill="none" stroke="#e5ebdf" stroke-width="7"/>
      ${meterEl.outerHTML}
      <strong id="meter-strong" class="strong" style="position:absolute; inset:0; text-align:center; line-height:100px;">${fa(done)} از ۵</strong>
    `;

    // Stats
    const statsEl = document.createElement('div');
    statsEl.className = 'stats';
    statsEl.innerHTML = `
      <div class="stat"><b>${fa(done)}</b><span>نماز خوانده‌شده</span></div>
      <div class="stat"><b>${fa(kh)}</b><span>با توجه و خشوع</span></div>
      <div class="stat"><b>${fa(5 - done)}</b><span>باقی‌مانده</span></div>
    `;

    // Prayers list
    const prayersList = document.createElement('div');
    prayersList.className = 'prayer-list';

    prayerKeys.forEach(k => {
      const item = state[k] || { done: false, khushu: false };
      const prayerEl = document.createElement('div');
      prayerEl.className = `prayer${item.done ? ' done' : ''}`;
      prayerEl.dataset.key = k;

      // Prayer icon + info
      const iconEl = document.createElement('div');
      iconEl.className = 'prayer-icon';
      iconEl.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
          <path d="M3 17h18M6 20h12M12 3v3M5 7l2 2m12-2-2 2"/>
          <path d="M5 16a7 7 0 0 1 14 0"/>
        </svg>
      `;

      const infoEl = document.createElement('div');
      infoEl.className = 'prayer-info';
      infoEl.innerHTML = `
        <div class="prayer-name">${k === 'fajr' ? 'نماز صبح' : k === 'dhuhr' ? 'نماز ظهر' : k === 'asr' ? 'نماز عصر' : k === 'maghrib' ? 'نماز مغرب' : 'نماز عشاء'</div>
        <div class="prayer-ar">${k === 'fajr' ? 'صلاة الفجر' : k === 'dhuhr' ? 'صلاة الظهر' : k === 'asr' ? 'صلاة العصر' : k === 'maghrib' ? 'صلاة المغرب' : 'صلاة العشاء'}</div>
      `;

      const check = document.createElement('input');
      check.type = 'checkbox';
      check.className = 'check done-box';
      check.checked = item.done;
      check.ariaLabel = `نماز ${k} خوانده شد`;

      check.addEventListener('change', (e) => {
        state[k] = { done: e.target.checked, khushu: item.khushu };
        if (!e.target.checked) state[k].khushu = false;
        writeDay(todayKey, state);
        // Re-render this section
        renderPrayers();
        renderStats();
        renderFraction();
      });

      // Khushu row
      const khushuEl = document.createElement('div');
      khushuEl.className = 'khushu-row';
      khushuEl.innerHTML = `
        <span>${k === 'fajr' ? 'آیا در نماز صبح توجه داشتید؟' : k === 'dhuhr' ? 'آیا در نماز ظهر توجه داشتید؟' : k === 'asr' ? 'آیا در نماز عصر توجه داشتید؟' : k === 'maghrib' ? 'آیا در نماز مغرب توجه داشتید؟' : 'آیا در نماز عشاء توجه داشتید؟'}</span>
        <label><input type="checkbox" ${item.khushu ? 'checked' : ''} id="khushu-${k}"> ثبت خشوع</label>
      `;

      // Khushu change
      const khushuInput = khushuEl.querySelector('input');
      khushuInput.addEventListener('change', (e) => {
        if (state[k]) state[k].khushu = e.target.checked;
        writeDay(todayKey, state);
        renderStats();
      });

      prayerEl.appendChild(iconEl);
      prayerEl.appendChild(infoEl);
      prayerEl.appendChild(check);
      prayerEl.appendChild(khushuEl);
      prayersList.appendChild(prayerEl);
    });

    // Reset button
    const resetBtn = document.createElement('button');
    resetBtn.className = 'action secondary';
    resetBtn.textContent = 'پاک‌کردن ثبت‌های امروز';
    resetBtn.addEventListener('click', () => {
      if (confirm('همه ثبت‌های امروز پاک شود؟')) {
        state = {};
        writeDay(todayKey, state);
        renderPrayers();
        renderStats();
        renderFraction();
      }
    });

    // Tip
    const tipEl = document.createElement('div');
    tipEl.className = 'tip';
    tipEl.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="12" cy="12" r="9"/>
        <path d="M12 11v5m0-8h.01"/>
      </svg>
      <span>خشوع را جداگانه و با مهربانی نسبت به خودت ثبت کن. اگر حواست پرت شد یا احساس خاصی نداشتی، خودت را سرزنش نکن؛ دوباره با آرامش تلاش کن.</span>
    `;

    // Assemble card
    const card = document.createElement('div');
    card.className = 'card hero';
    card.innerHTML = `
      <div class="hero-top">
        <div>
          <h2>پیشرفت امروز</h2>
          <div class="muted">هر نماز، یک قدم ارزشمند</div>
        </div>
        ${ringSvg.outerHTML}
        <strong id="fraction">${fa(done)} از ۵</strong>
      </div>
    `;

    // Main content
    const mainContent = document.createElement('div');
    mainContent.className = 'card';
    mainContent.innerHTML = `
      <div class="section-head">
        <h2>نمازهای پنج‌گانه</h2>
        <span class="muted">برای ثبت، دایره را تیک بزن</span>
      </div>
    `;

    // Append everything
    const app = document.getElementById('app');
    if (app) {
      app.innerHTML = '';
      app.appendChild(todayEl);
      app.appendChild(card);
      app.appendChild(statsEl);
      app.appendChild(prayersList);
      app.appendChild(tipEl);
      app.appendChild(resetBtn);
    }

    // Attach event listeners after render
    attachPrayerListeners();

    function attachPrayerListeners() {
      document.querySelectorAll('.prayer').forEach(el => {
        const k = el.dataset.key;
        el.querySelector('.done-box').addEventListener('change', e => {
          state[k] = { done: e.target.checked, khushu: el.querySelector('.khushu-row input').checked };
          if (!e.target.checked) state[k].khushu = false;
          writeDay(todayKey, state);
          renderPrayers();
          renderStats();
          renderFraction();
        });
      });
    }

    function renderPrayers() {
      state = readDay(todayKey);
      done = 0; kh = 0;
      prayerKeys.forEach(k => {
        if (state[k]?.done) done++;
        if (state[k]?.khushu) kh++;
      });
      fractionEl.textContent = `${fa(done)} از ۵`;
      meterEl.setAttribute('stroke-dasharray', `${circ * done / 5} ${circ}`);
      document.getElementById('meter-strong').textContent = `${fa(done)} از ۵`;
      document.querySelectorAll('.stat b').forEach((el, i) => {
        if (i === 0) el.textContent = fa(done);
        if (i === 1) el.textContent = fa(kh);
        if (i === 2) el.textContent = fa(5 - done);
      });
      document.querySelectorAll('.prayer').forEach(el => {
        const k = el.dataset.key;
        const item = state[k] || { done: false, khushu: false };
        el.classList.toggle('done', !!item.done);
        el.querySelector('.done-box').checked = !!item.done;
      });
    }

    function renderStats() {
      document.querySelectorAll('.stat b').forEach((el, i) => {
        if (i === 0) el.textContent = fa(done);
        if (i === 1) el.textContent = fa(kh);
        if (i === 2) el.textContent = fa(5 - done);
      });
    }

    function renderFraction() {
      fractionEl.textContent = `${fa(done)} از ۵`;
      meterEl.setAttribute('stroke-dasharray', `${circ * done / 5} ${circ}`);
      document.getElementById('meter-strong').textContent = `${fa(done)} از ۵`;
    }
  }
};