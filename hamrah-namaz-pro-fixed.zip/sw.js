/* ===== همراه نماز من — Service Worker (PWA) =====
 * استراتژی:
 * - فایل‌های اپلیکیشن: cache-first (آفلاین)
 * - API quran.com: network-first با کش
 */

const CACHE = 'hamrah-namaz-v1';
const API_CACHE = 'hamrah-namaz-api-v1';
const APP_SHELL = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.svg',
  '/css/base.css',
  '/css/components.css',
  '/css/layout.css',
  '/css/pages.css',
  '/js/main.js'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(APP_SHELL)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => !k.startsWith('hamrah-namaz')).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;

  // API قرآن: network-first
  if (url.hostname.includes('quran.com')) {
    e.respondWith(
      fetch(e.request)
        .then((res) => {
          const clone = res.clone();
          caches.open(API_CACHE).then((c) => c.put(e.request, clone));
          return res;
        })
        .catch(() => caches.match(e.request).then((m) => m || new Response('offline', { status: 503 })))
    );
    return;
  }

  // فایل‌های اپ: cache-first
  if (url.origin === self.location.origin) {
    e.respondWith(
      caches.match(e.request).then(
        (m) =>
          m ||
          fetch(e.request).then((res) => {
            if (res.ok) {
              const clone = res.clone();
              caches.open(CACHE).then((c) => c.put(e.request, clone));
            }
            return res;
          }).catch(() => m)
      )
    );
  }
});
