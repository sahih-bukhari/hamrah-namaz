/*
 * Router — مدیریتrouting ساده برای SPA
 * - پشتیبانی از History API
 - تغییر URL بدون ریلود
 - بارگذاری صفحات lazy
 - Support back/forward browser buttons
 */

const routes = {
  '/': 'pages/Dashboard.js',
  '/dashboard': 'pages/Dashboard.js',
  '/prayers': 'pages/Prayers.js',
  '/tasbih': 'pages/Tasbih.js',
  '/dhikr': 'pages/Dhikr.js',
  '/quran': 'pages/Quran.js',
  '/reports': 'pages/Reports.js',
  '/goals': 'pages/Goals.js',
  '/learn': 'pages/Learn.js',
  '/achievements': 'pages/Achievements.js',
  '/settings': 'pages/Settings.js',
};

let currentPage = null;

export default {
  init() {
    // Handle navigation
    document.body.addEventListener('click', (e) => {
      const link = e.target.closest('a[href^="/"]');
      if (link && !e.target.closest('button')) {
        e.preventDefault();
        const href = link.getAttribute('href');
        this.navigate(href);
      }
    });

    // Handle popstate (back/forward buttons)
    window.addEventListener('popstate', () => {
      this.load(currentPage || '/');
    });

    // Initial load
    const path = this.getPath();
    this.load(path);
  },

  getPath() {
    return window.location.pathname || '/';
  },

  navigate(path) {
    // Normalize path
    const normalizedPath = path.startsWith('/') ? path : '/' + path;
    history.pushState({}, '', normalizedPath);
    this.load(normalizedPath);
  },

  async load(path) {
    const page = routes[path];
    if (!page) {
      console.warn(`Route not found: ${path}`);
      return;
    }

    // Avoid reloading same page
    if (currentPage === page) return;
    currentPage = page;

    // Show loading state
    const app = document.getElementById('app');
    if (app) {
      app.innerHTML = '<div class="empty" style="padding:40px 20px;">در حال بارگذاری...</div>';
    }

    try {
      // Dynamic import
      const module = await import(`/${page}`);
      const pageComponent = module.default || module;
      if (typeof pageComponent.render === 'function') {
        app.innerHTML = '';
        pageComponent.render();
      } else {
        app.innerHTML = `<div class="empty" style="padding:40px 20px;">صفحه یافت نشد</div>`;
      }
    } catch (err) {
      console.error('Route load error:', err);
      const app = document.getElementById('app');
      if (app) {
        app.innerHTML = `<div class="empty" style="padding:40px 20px;color:red;">خطا در بارگذاری صفحه</div>`;
      }
    }
  }
};