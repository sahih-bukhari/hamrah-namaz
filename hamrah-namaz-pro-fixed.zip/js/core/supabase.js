/* ===== همراه نماز من — لایه همگام‌سازی Supabase (اختیاری) =====
 * اپلیکیشن به‌صورت offline-first کار می‌کند.
 * فقط وقتی Supabase پیکربندی شده باشد (متغیرهای محیطی VITE_SUPABASE_URL و
 * VITE_SUPABASE_ANON_KEY در build)، داده‌ها به‌صورت امن با REST API
 * (PostgREST) همگام می‌شوند. RLS سمت سرور، دسترسی‌ها را محدود می‌کند.
 *
 * هیچ کلید محرمانه در کد سمت کاربر قرار نمی‌گیرد؛ فقط anon key عمومی
 * (که برای مرورگر طراحی شده) از طریق import.meta.env خوانده می‌شود.
 */

const SUPA_URL = (import.meta.env.VITE_SUPABASE_URL || '').replace(/\/$/, '');
const SUPA_ANON = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const supabaseEnabled = Boolean(SUPA_URL && SUPA_ANON);

/* کلیدهای Store که به جدول users_data می‌نشینند (کلید = نام ستون) */
const SYNCABLE = new Set([
  'settings',
  'tasbih',
  'adhkar_favs',
  'quran',
  'goals',
  'learn',
  'achievements',
  'user',
]);

/* روزهای نماز در جدول prayer_days با ستون date_key ذخیره می‌شوند */
const DAY_KEY_RE = /^day:(\d{4}-\d{2}-\d{2})$/;

const queue = []; // { key, value, ts }
let syncing = false;

function headers() {
  return {
    apikey: SUPA_ANON,
    Authorization: `Bearer ${SUPA_ANON}`,
    'Content-Type': 'application/json',
    'X-Client-Info': 'hamrah-namaz/1.0',
  };
}

async function api(path, opts = {}) {
  const res = await fetch(SUPA_URL + path, {
    ...opts,
    headers: { ...headers(), ...(opts.headers || {}) },
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`Supabase ${res.status}: ${body.slice(0, 200)}`);
  }
  return res.status === 204 ? null : res.json();
}

/** خواندن کاربر فعلی (token را Supabase SDK مدیریت می‌کند؛ در حالت anon بدون login، null) */
export async function getCurrentUser() {
  if (!supabaseEnabled) return null;
  const user = StoreUser.get();
  if (!user?.accessToken) return null;
  const res = await fetch(SUPA_URL + '/auth/v1/user', {
    headers: {
      apikey: SUPA_ANON,
      Authorization: `Bearer ${user.accessToken}`,
    },
  });
  if (!res.ok) return null;
  return res.json();
}

const StoreUser = {
  get() {
    try {
      return JSON.parse(localStorage.getItem('hamrah_pro:auth') || 'null');
    } catch (e) {
      return null;
    }
  },
  set(v) {
    try {
      if (v) localStorage.setItem('hamrah_pro:auth', JSON.stringify(v));
      else localStorage.removeItem('hamrah_pro:auth');
    } catch (e) { /* بی‌خطر */ }
  },
};

/** ثبت‌نام / ورود با ایمیل و رمز (Supabase Auth) */
export async function signIn(email, password) {
  if (!supabaseEnabled) throw new Error('Supabase پیکربندی نشده است');
  const res = await fetch(SUPA_URL + '/auth/v1/token?grant_type=password', {
    method: 'POST',
    headers: { ...headers(), 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error_description || data.msg || 'ورود ناموفق بود');
  StoreUser.set({
    id: data.user?.id,
    email: data.user?.email,
    accessToken: data.access_token,
    refreshToken: data.refresh_token,
  });
  return data.user;
}

export async function signUp(email, password) {
  if (!supabaseEnabled) throw new Error('Supabase پیکربندی نشده است');
  const res = await fetch(SUPA_URL + '/auth/v1/signup', {
    method: 'POST',
    headers: { ...headers(), 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error_description || data.msg || 'ثبت‌نام ناموفق بود');
  StoreUser.set({
    id: data.user?.id,
    email: data.user?.email,
    accessToken: data.access_token,
    refreshToken: data.refresh_token,
  });
  return data.user;
}

export async function signOut() {
  const u = StoreUser.get();
  if (u?.accessToken) {
    try {
      await fetch(SUPA_URL + '/auth/v1/logout', {
        method: 'POST',
        headers: {
          apikey: SUPA_ANON,
          Authorization: `Bearer ${u.accessToken}`,
        },
      });
    } catch (e) { /* بی‌خطر */ }
  }
  StoreUser.set(null);
}

export function isSignedIn() {
  return Boolean(StoreUser.get()?.accessToken);
}

/* ---------- صف همگام‌سازی ---------- */

function authHeaders() {
  const u = StoreUser.get();
  if (u?.accessToken) {
    return { Authorization: `Bearer ${u.accessToken}` };
  }
  return {};
}

async function flush() {
  if (!supabaseEnabled || !isSignedIn() || syncing) return;
  syncing = true;
  try {
    while (queue.length) {
      const item = queue.shift();
      if (item.value === null) continue; // حذف: فقط در صورت نیاز (حذف حساب)
      try {
        if (DAY_KEY_RE.test(item.key)) {
          const dateKey = item.key.match(DAY_KEY_RE)[1];
          await api('/rest/v1/prayer_days?on_conflict=user_id,date_key', {
            method: 'POST',
            headers: { Prefer: 'resolution=merge-duplicates', ...authHeaders() },
            body: JSON.stringify({ date_key: dateKey, data: item.value }),
          });
        } else if (SYNCABLE.has(item.key)) {
          await api(`/rest/v1/user_data?on_conflict=user_id,key`, {
            method: 'POST',
            headers: { Prefer: 'resolution=merge-duplicates', ...authHeaders() },
            body: JSON.stringify({ key: item.key, data: item.value }),
          });
        }
      } catch (e) {
        // خطای موقت: به صف برگردد و دوباره امتحان شود
        queue.push(item);
        console.warn('[Supabase] همگام‌سازی بعداً تکرار می‌شود:', e.message);
        break;
      }
    }
  } finally {
    syncing = false;
  }
}

export const supabaseQueue = {
  /** افزودن تغییر به صف و تلاش برای ارسال */
  enqueue(key, value) {
    if (!supabaseEnabled || !isSignedIn()) return;
    if (!SYNCABLE.has(key) && !DAY_KEY_RE.test(key)) return;
    // جلوگیری از ثبت تکراری: آخرین مقدار هر کلید جایگزین می‌شود
    const i = queue.findIndex((q) => q.key === key);
    const item = { key, value, ts: Date.now() };
    if (i >= 0) queue.splice(i, 1, item);
    else queue.push(item);
    flush();
  },

  /** تعداد تغییرات ارسال‌نشده (نمایش در تنظیمات) */
  pending() {
    return queue.length;
  },

  clear() {
    queue.length = 0;
  },

  /** بارگذاری داده‌ها از ابر (پس از ورود، برای همگام‌سازی بین دستگاه‌ها) */
  async pullAll() {
    if (!supabaseEnabled || !isSignedIn()) return [];
    const results = [];
    const [userData, days] = await Promise.all([
      api('/rest/v1/user_data?select=key,data').catch(() => []),
      api('/rest/v1/prayer_days?select=date_key,data&order=date_key.desc&limit=400').catch(() => []),
    ]);
    userData.forEach((r) => results.push({ key: r.key, value: r.data }));
    days.forEach((r) => results.push({ key: 'day:' + r.date_key, value: r.data }));
    return results;
  }
};
