/*
 * Theme — مدیریت حالت روشن/تاریک
 * - از prefers-color-system شروع می‌کند
 - ذخیره در localStorage
 - تعویض روی دکمه/body
 */

export default {
  init() {
    // Check for saved preference or system
    const saved = localStorage.getItem('app-theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const initial = saved ? saved : (systemPrefersDark ? 'dark' : 'light');
    this.set(initial);
  },

  set(mode) {
    const html = document.documentElement;
    if (mode === 'dark') {
      html.setAttribute('data-theme', 'dark');
    } else {
      html.removeAttribute('data-theme');
    }
    localStorage.setItem('app-theme', mode);
  },

  toggle() {
    const current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    this.set(current);
  }
};