/*
 * Store — مدیریت state با پشتیبانی از localStorage و لایه Supabase آینده
 * کلیدهای localStorage: hamrah-pro-<key>
 * ساختار داده‌ها طوری طراحی شده که با تغییر config Supabase قابل مهاجرت است.
 */

const STORAGE_PREFIX = 'hamrah-pro-';
const DEFAULT_STATE = {
  user: null, // { id, name, email } - populated after Supabase login
  theme: 'light', // 'light' | 'dark'
  language: 'fa', // 'fa' | 'dar'
  // per-page states will be initialized by page modules
};

/**
 * Get stored state for a given key, merging with defaults
 */
function getStored(key, defaults = {}) {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + key);
    if (!raw) return { ...DEFAULT_STATE, ...defaults };
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_STATE, ...parsed, ...defaults };
  } catch (e) {
    console.warn('Store read error:', e);
    return { ...DEFAULT_STATE, ...defaults };
  }
}

/**
 * Save state to localStorage
 */
function setStored(key, state) {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(state));
  } catch (e) {
    console.error('Store write error:', e);
  }
}

/**
 * Clear all state (for logout/reset)
 */
function clearAll() {
  try {
    const keys = Object.keys(localStorage);
    keys.forEach(k => {
      if (k.startsWith(STORAGE_PREFIX)) localStorage.removeItem(k);
    });
  } catch (e) {
    console.error('Store clear error:', e);
  }
}

/**
 * Export public API
 */
export default {
  getStored,
  setStored,
  clearAll,
  // Per-page helpers
  setPageState(page, state) {
    const key = `${page}-state`;
    this.setStored(key, state);
  },
  getPageState(page) {
    return this.getStored(`${page}-state`, {});
  },
  // Supabase sync (stub — to be connected when config available)
  async syncToSupabase() {
    // Will be implemented when Supabase credentials are provided
    // This method exists so pages can call it without errors
    return { synced: 0, failed: 0 };
  },
  onSync(cb) {
    // Callback for when sync completes
    cb(this.syncToSupabase());
  }
};