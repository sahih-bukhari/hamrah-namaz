/* ===== همراه نماز من — Router =====
 * SPA با History API:
 * - مسیریابی بدون ریلود
 * - پشتیبانی از Back/Forward مرورگر
 * - بارگذاری lazy صفحات
 */

import { App } from './app.js';

const routes = {
  '/': () => import('../../pages/dashboard.js'),
  '/prayers': () => import('../../pages/prayers.js'),
  '/tasbih': () => import('../../pages/tasbih.js'),
  '/dhikr': () => import('../../pages/dhikr.js'),
  '/quran': () => import('../../pages/quran.js'),
  '/reports': () => import('../../pages/reports.js'),
  '/goals': () => import('../../pages/goals.js'),
  '/learn': () => import('../../pages/learn.js'),
  '/achievements': () => import('../../pages/achievements.js'),
  '/settings': () => import('../../pages/settings.js'),
};

let currentModule = null;

export const Router = {
  init() {
    window.__router = this;

    // کلیک روی لینک‌های داخلی (سایدبار/بیشتر/هرجا)
    document.body.addEventListener('click', (e) => {
      const link = e.target.closest('a[href^="/"]');
      if (!link) return;
      if (e.metaKey || e.ctrlKey || e.shiftKey) return;
      e.preventDefault();
      this.navigate(link.getAttribute('href'));
    });

    // Back/Forward مرورگر
    window.addEventListener('popstate', () => {
      this.load(this.getPath(), false);
    });

    // بارگذاری اولیه
    const path = this.getPath();
    if (!routes[path]) {
      history.replaceState({}, '', '/');
      this.load('/');
    } else {
      this.load(path);
    }
  },

  getPath() {
    const p = window.location.pathname;
    return routes[p] ? p : '/';
  },

  navigate(path) {
    const target = routes[path] ? path : '/';
    if (target === this.getPath()) {
      App.setActive(target);
      return;
    }
    history.pushState({}, '', target);
    this.load(target);
  },

  async load(path) {
    const loader = routes[path];
    if (!loader) {
      App.setActive('/');
      this.load('/');
      return;
    }

    App.setActive(path);

    const page = document.getElementById('page');
    if (!page) return;
    page.innerHTML = `<div class="empty">${this.t_loading()}</div>`;
    page.scrollTop = 0;
    window.scrollTo({ top: 0 });

    try {
      const mod = await loader();
      // جلوگیری از ناهماهنگی در صورت جابه‌جایی سریع کاربر
      if (this.getPath() !== path) return;
      currentModule = mod;
      page.innerHTML = '';
      const comp = mod.default || mod;
      if (typeof comp.render === 'function') {
        comp.render(page);
        page.classList.remove('page-anim');
        void page.offsetWidth; // ری‌استارت انیمیشن
        page.classList.add('page-anim');
      } else {
        page.innerHTML = `<div class="empty">صفحه نامعتبر است</div>`;
      }
    } catch (err) {
      console.error('[Router] خطا در بارگذاری صفحه:', err);
      page.innerHTML = `
        <div class="empty">
          <p>خطا در بارگذاری صفحه</p>
          <p class="muted" style="font-size:.75rem;margin-top:6px">${String(err.message || err).slice(0, 120)}</p>
        </div>`;
    }
  },

  t_loading() {
    return 'در حال بارگذاری...';
  }
};

export default Router;
