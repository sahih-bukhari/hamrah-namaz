/* ===== همراه نماز من — مدیریت تم و اندازه فونت ===== */

import Store from './store.js';

const DEFAULTS = {
  theme: 'light',   // light | dark
  language: 'fa',   // fa | dar
  fontScale: 1,     // 0.9 | 1 | 1.1
  vibration: true,
  sound: false,
  reminders: false,
  reminderTime: '05:00'
};

export const Theme = {
  settings() {
    return { ...DEFAULTS, ...(Store.get('settings', {}) || {}) };
  },

  save(patch) {
    const next = { ...this.settings(), ...patch };
    Store.set('settings', next);
    this.apply(next);
    return next;
  },

  /** اعمال تم و فونت روی DOM */
  apply(s = this.settings()) {
    const html = document.documentElement;
    if (s.theme === 'dark') html.setAttribute('data-theme', 'dark');
    else html.removeAttribute('data-theme');
    html.style.setProperty('--font-scale', String(s.fontScale || 1));
    html.setAttribute('lang', s.language === 'dar' ? 'fa-AF' : 'fa');
    html.setAttribute('dir', 'rtl');
  },

  toggle() {
    const s = this.settings();
    this.save({ theme: s.theme === 'dark' ? 'light' : 'dark' });
  },

  init() {
    const s = this.settings();
    if (!s.theme) {
      const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
      this.save({ theme: prefersDark ? 'dark' : 'light' });
    } else {
      this.apply(s);
    }
    // دنبال‌کننده تغییر سیستم (فقط وقتی کاربر خودش انتخاب نکرده)
    try {
      window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
        const cur = this.settings();
        if (cur.theme === 'auto') this.apply({ ...cur, theme: e.matches ? 'dark' : 'light' });
      });
    } catch (err) { /* بی‌خطر */ }
  }
};

export default Theme;
