/* ===== همراه نماز من — i18n (فارسی / دری) =====
 * هر دو زبان RTL هستند؛ تفاوت‌ها در املای برخی واژه‌ها و
 * قالب تاریخ (دری: fa-AF) است.
 */

import Store from './store.js';
import { DOW, MONTHS_FA } from '../utils/helpers.js';

const MESSAGES = {
  fa: {
    appName: 'همراه نماز من',
    tagline: 'قدم‌های کوچک، پایداری بزرگ',
    dashboard: 'داشبورد',
    prayers: 'نمازها',
    tasbih: 'تسبیح',
    dhikr: 'اذکار و دعا',
    quran: 'قرآن کریم',
    reports: 'گزارش‌ها',
    goals: 'برنامه‌ریزی عبادت',
    learn: 'آموزش دین',
    achievements: 'نشان‌ها',
    settings: 'تنظیمات',
    more: 'بیشتر',
    today: 'امروز',
    yesterday: 'دیروز',
    tomorrow: 'فردا',
    done: 'انجام شد',
    remaining: 'باقی‌مانده',
    withKhushu: 'با خشوع ثبت‌شده',
    dailyProgress: 'پیشرفت امروز',
    everyPrayer: 'هر نماز، یک قدم ارزشمند',
    fivePrayers: 'نمازهای پنج‌گانه',
    markDone: 'برای ثبت، تیک بزنید',
    dailyNote: 'یادداشت روزانه',
    dailyNotePh: 'یک جمله درباره نماز یا حال امروزت...',
    qadaTitle: 'نمازهای قضا (جبران)',
    qadaHint: 'نمازهای قضا را جدا از ادا، در روزی که جبران می‌کنی ثبت کن.',
    weeklyReport: 'نگاهی به هفت روز گذشته',
    clearToday: 'پاک‌کردن ثبت‌های امروز',
    clearTodayMsg: 'همه ثبت‌های امروز (ادا، قضا و یادداشت) پاک شود؟',
    prayerDone: 'نماز ثبت شد',
    prayerUndone: 'ثبت برداشته شد',
    saved: 'ذخیره شد',
    copied: 'کپی شد',
    favorites: 'علاقه‌مندی‌ها',
    source: 'منبع',
    count: 'تعداد',
    time: 'زمان',
    cancel: 'انصراف',
    save: 'ذخیره',
    delete: 'حذف',
    edit: 'ویرایش',
    close: 'بستن',
    add: 'افزودن',
    search: 'جستجو...',
    noData: 'هنوز داده‌ای ثبت نشده است',
    loading: 'در حال بارگذاری...',
    offline: 'آفلاین — محتوای ذخیره‌شده نمایش داده می‌شود',
  },
  dar: {
    appName: 'همراه نماز من',
    tagline: 'قدم‌های کوچک، پایداری بزرگ',
    dashboard: 'داشبورد',
    prayers: 'نمازها',
    tasbih: 'تسبیح',
    dhikr: 'اذکار و دعا',
    quran: 'قرآن کریم',
    reports: 'گزارش‌ها',
    goals: 'برنامه‌ریزی عبادت',
    learn: 'آموزش دین',
    achievements: 'نشان‌ها',
    settings: 'تنظیمات',
    more: 'بیشتر',
    today: 'امروز',
    yesterday: 'دیروز',
    tomorrow: 'فردا',
    done: 'انجام شد',
    remaining: 'باقی‌مانده',
    withKhushu: 'با خشوع ثبت‌شده',
    dailyProgress: 'پیشرفت امروز',
    everyPrayer: 'هر نماز، یک قدم ارزشمند',
    fivePrayers: 'نمازهای پنج‌گانه',
    markDone: 'برای ثبت، تیک بزنید',
    dailyNote: 'یادداشت روزانه',
    dailyNotePh: 'یک جمله درباره نماز یا حال امروزت...',
    qadaTitle: 'نمازهای قضا (جبران)',
    qadaHint: 'نمازهای قضا را جدا از ادا، در روزی که جبران می‌کنی ثبت کن.',
    weeklyReport: 'نگاهی به هفت روز گذشته',
    clearToday: 'پاک‌کردن ثبت‌های امروز',
    clearTodayMsg: 'همه ثبت‌های امروز (ادا، قضا و یادداشت) پاک شود؟',
    prayerDone: 'نماز ثبت شد',
    prayerUndone: 'ثبت برداشته شد',
    saved: 'ذخیره شد',
    copied: 'کپی شد',
    favorites: 'علاقه‌مندی‌ها',
    source: 'منبع',
    count: 'تعداد',
    time: 'زمان',
    cancel: 'انصراف',
    save: 'ذخیره',
    delete: 'حذف',
    edit: 'ویرایش',
    close: 'بستن',
    add: 'افزودن',
    search: 'جستجو...',
    noData: 'هنوز داده‌ای ثبت نشده است',
    loading: 'در حال بارگذاری...',
    offline: 'آفلاین — محتوای ذخیره‌شده نمایش داده می‌شود',
  }
};

const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';

export const i18n = {
  lang() {
    return Store.get('settings', { language: 'fa' }).language || 'fa';
  },

  locale() {
    return this.lang() === 'dar' ? 'fa-AF' : 'fa-IR';
  },

  t(key) {
    const lang = MESSAGES[this.lang()] || MESSAGES.fa;
    return lang[key] ?? MESSAGES.fa[key] ?? key;
  },

  /** تاریخ به فارسی/دری */
  formatDate(d, opts = {}) {
    const base = { day: 'numeric', month: 'long', ...opts };
    try {
      return new Intl.DateTimeFormat(this.locale(), base).format(d);
    } catch (e) {
      return d.toLocaleDateString('fa-IR', base);
    }
  },

  /** تاریخ کامل با روز هفته */
  formatFullDate(d) {
    try {
      return new Intl.DateTimeFormat(this.locale(), {
        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
      }).format(d);
    } catch (e) {
      return d.toLocaleDateString('fa-IR');
    }
  },

  toFa(n) {
    if (n === null || n === undefined) return '';
    return String(n).replace(/\d/g, (d) => FA_DIGITS[+d]);
  }
};

export default i18n;
