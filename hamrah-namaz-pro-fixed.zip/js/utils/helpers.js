/* ===== همراه نماز من — توابع کمکی ===== */

const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';

/** تبدیل ارقام لاتین به فارسی */
export function faNum(n) {
  if (n === null || n === undefined) return '';
  return String(n).replace(/\d/g, (d) => FA_DIGITS[+d]);
}

/** عدد با جداکننده هزارگان + ارقام فارسی */
export function faNumBig(n) {
  if (n === null || n === undefined) return '';
  const s = Math.round(Math.abs(n)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '٬');
  return faNum(n < 0 ? '-' + s : s);
}

/** کلید تاریخ محلی: YYYY-MM-DD (منطقه زمانی کاربر) */
export function dayKey(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/** ساخت Date از کلید YYYY-MM-DD (تاریخ محلی) */
export function keyToDate(key) {
  const [y, m, d] = key.split('-').map(Number);
  return new Date(y, m - 1, d);
}

/** تاریخ امروز به کلید */
export function todayKey() {
  return dayKey(new Date());
}

/** n روز قبل از امروز (به کلید) */
export function daysAgoKey(n, base = new Date()) {
  const d = new Date(base);
  d.setDate(d.getDate() - n);
  return dayKey(d);
}

/** نام روز هفته (فارسی) */
export const DOW = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
export const DOW_SHORT = ['یک', 'دو', 'سه', 'چهار', 'پنج', 'جمعه', 'شنبه'];
export const MONTHS_FA = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
export const MONTHS_AF = MONTHS_FA;
// نام ماه‌های میلادی (برای تقویم داخلی)
export const MONTHS_G = ['ژانویه', 'فوریه', 'مارس', 'آوریل', 'مه', 'ژوئن', 'ژوئیه', 'اوت', 'سپتامبر', 'اکتبر', 'نوامبر', 'دسامبر'];

/* ===== تبدیل تقویم میلادی ↔ هجری شمسی (استاندارد افغانستان) ===== */
/** آیا سال شمسی کبیسه است؟ */
export function isLeapJalaali(jy) {
  return (jy % 33 === 1 || jy % 33 === 5 || jy % 33 === 9 || jy % 33 === 13 ||
          jy % 33 === 17 || jy % 33 === 22 || jy % 33 === 26 || jy % 33 === 30);
}
/** تعداد روزهای ماه شمسی */
export function jalaaliMonthLength(jy, jm) {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isLeapJalaali(jy) ? 30 : 29;
}
/** میلادی → شمسی: [jy, jm, jd] */
export function gregorianToJalali(gy, gm, gd) {
  const g_d_m = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let jy;
  if (gy <= 1600) { jy = 0; gy -= 621; }
  else { jy = 979; gy -= 1600; }
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days = 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) - 80 + gd;
  for (let i = 0; i < gm - 1; i++) days += g_d_m[i];
  if (gm > 2 && ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0)) days++;
  let jy2 = 979 + Math.floor(days / 365.2422);
  days -= (jy2 - 979) * 365 + Math.floor((jy2 - 979) / 33) * 8 + Math.floor(((jy2 - 979) % 33 + 3) / 4);
  let leap = 0;
  if (days >= 366) { leap = 1; jy2 += 1; days -= 366; }
  let jm, jd;
  if (days < 186) { jm = 1 + Math.floor(days / 31); jd = 1 + (days % 31); }
  else { jm = 7 + Math.floor((days - 186) / 30); jd = 1 + ((days - 186) % 30); }
  jy = jy2 + (jy - 979);
  if (jy <= 0) jy = 1;
  return [jy, jm, jd];
}
/** شمسی → میلادی: [gy, gm, gd] */
export function jalaliToGregorian(jy, jm, jd) {
  let gy;
  if (jy <= 979) { jy += 621; gy = 0; }
  else { jy -= 979; gy = 1600; }
  const base = gy === 0 ? 0 : 1600;
  let days = (jy - 1) * 365 + Math.floor(jy / 33) * 8 + Math.floor(((jy % 33) + 3) / 4) + 78 + jd + (jm <= 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
  let gy2 = base + Math.floor(days / 365.2422);
  days -= (gy2 - base) * 365 + Math.floor((gy2 - base + 3) / 4) - Math.floor((gy2 - base + 99) / 100) + Math.floor((gy2 - base + 399) / 400);
  if (days > 365) { gy2++; days -= 365; }
  const g_d_m = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if ((gy2 % 4 === 0 && gy2 % 100 !== 0) || gy2 % 400 === 0) g_d_m[1] = 29;
  let gm = 0, gd = days;
  for (let i = 0; i < 12; i++) {
    if (gd <= g_d_m[i]) { gm = i + 1; break; }
    gd -= g_d_m[i];
  }
  return [gy2, gm, gd];
}
/** تبدیل کلید میلادی YYYY-MM-DD به رشته هجری شمسی افغانی */
export function formatJalali(key) {
  const [y, m, d] = key.split('-').map(Number);
  const [jy, jm, jd] = gregorianToJalali(y, m, d);
  return `${faNum(jd)} ${MONTHS_FA[jm - 1]} ${faNum(jy)}`;
}

/** ساخت شناسه یکتا */
export function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

/** اعتبارسنجی: رشته غیرخالی و کوتاه */
export function validText(v, max = 200) {
  return typeof v === 'string' && v.trim().length > 0 && v.trim().length <= max;
}

/** اعتبارسنجی عدد صحیح مثبت */
export function validInt(v, min = 1, max = 100000) {
  const n = Number(v);
  return Number.isInteger(n) && n >= min && n <= max;
}

/** اعتبارسنجی زمان HH:MM */
export function validTime(v) {
  return /^([01]\d|2[0-3]):[0-5]\d$/.test(v);
}

/** اعتبارسنجی ایمیل */
export function validEmail(v) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);
}

/** دانلود فایل متنی */
export function downloadFile(filename, content, mime = 'text/plain') {
  const blob = new Blob([content], { type: mime + ';charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}

/** خروجی CSV با BOM برای اکسل فارسی */
export function downloadCSV(filename, rows) {
  const csv = rows
    .map((r) => r.map((c) => `"${String(c ?? '').replace(/"/g, '""')}"`).join(','))
    .join('\n');
  downloadFile(filename, '\uFEFF' + csv, 'text/csv');
}

/** توست ساده */
export function toast(msg, type = 'success', ms = 2200) {
  const root = document.getElementById('toast-root');
  if (!root) return;
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  root.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .3s';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 320);
  }, ms);
}

/** مودال: بازگشت Promise با نتیجه */
export function openModal({ title, body, actions = [], onClose }) {
  const root = document.getElementById('modal-root');
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.setAttribute('role', 'dialog');
  modal.setAttribute('aria-modal', 'true');

  const head = document.createElement('div');
  head.className = 'modal-head';
  const h = document.createElement('h3');
  h.textContent = title || '';
  const closeBtn = document.createElement('button');
  closeBtn.className = 'icon-btn';
  closeBtn.setAttribute('aria-label', 'بستن');
  closeBtn.innerHTML = ICONS.close;
  head.append(h, closeBtn);

  const bodyEl = document.createElement('div');
  bodyEl.className = 'modal-body';
  if (typeof body === 'string') bodyEl.innerHTML = body;
  else if (body instanceof Node) bodyEl.appendChild(body);

  modal.appendChild(head);
  modal.appendChild(bodyEl);

  let closed = false;
  const close = (result) => {
    if (closed) return;
    closed = true;
    backdrop.remove();
    if (onClose) onClose();
  };

  if (actions.length) {
    const act = document.createElement('div');
    act.className = 'modal-actions';
    actions.forEach((a) => {
      const b = document.createElement('button');
      b.className = `btn ${a.cls || 'btn-soft'}`;
      b.innerHTML = a.label;
      b.addEventListener('click', () => {
        if (a.onClick) {
          const r = a.onClick(modal);
          if (r !== false) close(r);
        } else close();
      });
      act.appendChild(b);
    });
    modal.appendChild(act);
  }

  closeBtn.addEventListener('click', () => close());
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) close();
  });
  document.addEventListener('keydown', function esc(e) {
    if (e.key === 'Escape') {
      close();
      document.removeEventListener('keydown', esc);
    }
  });

  backdrop.append(modal);
  root.appendChild(backdrop);
  const firstInput = modal.querySelector('input,textarea,select,button.btn');
  if (firstInput) setTimeout(() => firstInput.focus(), 60);
  return { modal, close };
}

/** تأیید با پیام (Promise) */
export function confirmDialog(message, { title = 'تأیید', okLabel = 'بله', cancelLabel = 'انصراف', danger = false } = {}) {
  return new Promise((resolve) => {
    openModal({
      title,
      body: `<p style="font-size:.9rem;line-height:2">${message}</p>`,
      actions: [
        {
          label: okLabel,
          cls: danger ? 'btn-danger' : 'btn-primary',
          onClick: () => resolve(true),
        },
        {
          label: cancelLabel,
          cls: 'btn-ghost',
          onClick: () => resolve(false),
        },
      ],
      onClose: () => resolve(false),
    });
  });
}

/** لرزش اختیاری */
export function haptic(pattern = 12) {
  try {
    if (navigator.vibrate) navigator.vibrate(pattern);
  } catch (e) { /* بی‌خطر */ }
}

/* ===== آیکون‌های SVG (خطی، یکپارچه) ===== */
const S = (paths) =>
  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;

export const ICONS = {
  home: S('<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9.5 21v-6h5v6"/>'),
  mosque: S('<path d="M12 3c.5 2.5 3 4 5 5-2 .5-3.5 2-4 4h-2c-.5-2-2-3.5-4-4 2-1 4.5-2.5 5-5Z"/><path d="M4 21v-8l3-2v10M20 21v-8l-3-2v10M8 21v-5a4 4 0 0 1 8 0v5"/><path d="M2 21h20"/>'),
  beads: S('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="5.5" r="1.4"/><circle cx="18.5" cy="12" r="1.4"/><circle cx="12" cy="18.5" r="1.4"/><circle cx="5.5" cy="12" r="1.4"/>'),
  book: S('<path d="M12 6.5C10.5 5 8 4.5 4 4.5v13c4 0 6.5.5 8 2 1.5-1.5 4-2 8-2v-13c-4 0-6.5.5-8 2Z"/><path d="M12 6.5v13"/>'),
  quran: S('<path d="M4 19.5V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v13.5"/><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20v2.5a1 1 0 0 1-1 1H6.5A2.5 2.5 0 0 1 4 19.5Z"/><path d="M12 8.5c-.8-.9-2-1.2-3.5-1.2v6.4c1.5 0 2.7.3 3.5 1.2.8-.9 2-1.2 3.5-1.2V7.3c-1.5 0-2.7.3-3.5 1.2Z"/>'),
  chart: S('<path d="M4 20V10M10 20V4M16 20v-7M21 20H3"/>'),
  target: S('<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1"/>'),
  grad: S('<path d="m12 4 10 5-10 5L2 9l10-5Z"/><path d="M6 11.5V16c0 1.5 2.7 3 6 3s6-1.5 6-3v-4.5"/><path d="M22 9v5"/>'),
  trophy: S('<path d="M8 4h8v6a4 4 0 0 1-8 0V4Z"/><path d="M8 5H4.5c0 3.5 1.5 5 3.5 5M16 5h3.5c0 3.5-1.5 5-3.5 5"/><path d="M12 14v3m-4 4h8m-6.5-4h5l.5 4H8.5l.5-4Z"/>'),
  gear: S('<circle cx="12" cy="12" r="3.2"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3 1a7 7 0 0 0-2-1.2L14.2 3H9.8l-.4 2.5a7 7 0 0 0-2 1.2l-2.3-1-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.3-1a7 7 0 0 0 2 1.2l.4 2.5h4.4l.4-2.5a7 7 0 0 0 2-1.2l2.3 1 2-3.4-2-1.5c.1-.4.1-.8.1-1.2Z"/>'),
  sun: S('<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4m0-14.2-1.4 1.4M6.3 17.7l-1.4 1.4"/>'),
  moon: S('<path d="M20 14.5A8 8 0 1 1 9.5 4 6.5 6.5 0 0 0 20 14.5Z"/>'),
  sunrise: S('<path d="M3 18h18M6 21h12"/><path d="M12 9V4m0 0L9.5 6.5M12 4l2.5 2.5"/><path d="M6.5 18a5.5 5.5 0 0 1 11 0"/>'),
  sunset: S('<path d="M3 18h18M6 21h12"/><path d="M12 4v5m0 0 2.5-2.5M12 9 9.5 6.5"/><path d="M6.5 18a5.5 5.5 0 0 1 11 0"/>'),
  dusk: S('<path d="M3 18h18M6 21h12"/><path d="M12 13V5m0 0L9.5 7.5M12 5l2.5 2.5"/><path d="M5.5 18a6.5 6.5 0 0 1 13 0"/>'),
  star: S('<path d="m12 3 2.7 5.6 6.1.8-4.5 4.2 1.1 6-5.4-3-5.4 3 1.1-6L3.2 9.4l6.1-.8L12 3Z"/>'),
  copy: S('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>'),
  check: S('<path d="m4.5 12.5 5 5 10-11"/>'),
  close: S('<path d="m5 5 14 14M19 5 5 19"/>'),
  plus: S('<path d="M12 5v14M5 12h14"/>'),
  trash: S('<path d="M4 7h16M9 7V4h6v3m-8 0 1 13h8l1-13"/><path d="M10 11v6m4-6v6"/>'),
  edit: S('<path d="M4 20h4L19.5 8.5a2.1 2.1 0 0 0-3-3L5 17v3Z"/><path d="m14 7 3 3"/>'),
  back: S('<path d="M9 5l7 7-7 7"/>'),
  next: S('<path d="M15 5l-7 7 7 7"/>'),
  flame: S('<path d="M12 3c1 3-3 4.5-3 8a3 3 0 0 0 6 .2c1.2 1 2 2.4 2 4A5 5 0 0 1 7 15c0-5 4.5-6.5 5-12Z"/>'),
  bell: S('<path d="M6 9a6 6 0 1 1 12 0c0 5 2 6 2 6H4s2-1 2-6Z"/><path d="M10 19a2 2 0 0 0 4 0"/>'),
  download: S('<path d="M12 3v11m0 0 4-4m-4 4-4-4"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/>'),
  upload: S('<path d="M12 14V3m0 0 4 4m-4-4-4 4"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/>'),
  print: S('<path d="M7 8V3h10v5"/><rect x="3" y="8" width="18" height="9" rx="2"/><path d="M7 14h10v7H7z"/>'),
  search: S('<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>'),
  note: S('<path d="M5 4h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Z"/><path d="M8 9h8M8 13h8M8 17h5"/>'),
  heart: S('<path d="M12 20.5 4.7 13a4.8 4.8 0 0 1 6.8-6.8l.5.5.5-.5a4.8 4.8 0 0 1 6.8 6.8L12 20.5Z"/>'),
  play: S('<path d="M7 4.5v15l12-7.5-12-7.5Z"/>'),
  volume: S('<path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/>'),
  volumeOff: S('<path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="m17 9 4 6m0-6-4 6"/>'),
  more: S('<circle cx="12" cy="5" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="12" cy="19" r="1.3"/>'),
  calendar: S('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4m8-4v4"/>'),
  clock: S('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'),
  user: S('<circle cx="12" cy="8" r="4"/><path d="M4.5 20.5a7.5 7.5 0 0 1 15 0"/>'),
  cloud: S('<path d="M7 18a4.5 4.5 0 0 1-.4-9A6 6 0 0 1 18 8.5 4.25 4.25 0 0 1 17.5 18H7Z"/>'),
  lock: S('<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>'),
  refresh: S('<path d="M20 11a8 8 0 0 0-14.5-3.5M4 13a8 8 0 0 0 14.5 3.5"/><path d="M20 4v4h-4M4 20v-4h4"/>'),
  sparkle: S('<path d="M12 3v4m0 10v4M3 12h4m10 0h4M6 6l2.5 2.5m7 7L18 18M18 6l-2.5 2.5m-7 7L6 18"/>'),
  hand: S('<path d="M8 12V5.5a1.5 1.5 0 0 1 3 0V11m0-5.5v-1a1.5 1.5 0 0 1 3 0V11m0-4.5a1.5 1.5 0 0 1 3 0V13"/><path d="M17 11.5a1.5 1.5 0 0 1 3 .5c0 5-2.5 9-7.5 9S5 17.5 5 14v-2.5a1.5 1.5 0 0 1 3 0"/>'),
};

export function icon(name, cls = '') {
  return `<span class="ic ${cls}" aria-hidden="true">${ICONS[name] || ''}</span>`;
}
